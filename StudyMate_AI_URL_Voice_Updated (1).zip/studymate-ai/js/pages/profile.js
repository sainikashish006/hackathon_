/**
 * StudyMate AI — Profile Page (Settings)
 */
window.ProfilePage = {
  currentTab: 'profile',

  render(params = {}) {
    const root = document.getElementById('app-root');
    const user = AuthService.getCurrentUser();
    const profile = AuthService.getProfile();
    const tab = params.tab || 'profile';
    this.currentTab = tab;

    root.innerHTML = AppShell.renderLayout('Profile & Settings', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">👤 Profile & Settings</h1>
        </div>
      </div>

      <div class="grid" style="grid-template-columns:220px 1fr;gap:24px;">
        <!-- Sidebar -->
        <div class="card" style="padding:8px;">
          ${[
            {key:'profile', icon:'👤', label:'My Profile'},
            {key:'settings', icon:'⚙️', label:'AI Settings'},
            {key:'usage', icon:'📊', label:'Usage & Plan'},
            {key:'security', icon:'🔒', label:'Security'},
          ].map(t => `
            <button class="sidebar-item ${tab === t.key ? 'active' : ''}" onclick="ProfilePage.switchTab('${t.key}')" style="margin-bottom:2px;">
              <span class="sidebar-item-icon">${t.icon}</span>
              <span class="sidebar-item-label">${t.label}</span>
            </button>
          `).join('')}
        </div>

        <!-- Content -->
        <div id="profile-tab-content">
          ${this.renderTab(tab, user, profile)}
        </div>
      </div>
    `);
  },

  switchTab(tab) {
    this.currentTab = tab;
    Router.navigate('/profile?tab=' + tab);
  },

  renderTab(tab, user, profile) {
    if (tab === 'profile') return this.renderProfileTab(user, profile);
    if (tab === 'settings') return this.renderSettingsTab();
    if (tab === 'usage') return this.renderUsageTab();
    if (tab === 'security') return this.renderSecurityTab();
    return '';
  },

  renderProfileTab(user, profile) {
    return `
      <div class="card">
        <div class="card-header"><div class="card-title">My Profile</div></div>
        <div style="display:flex;align-items:center;gap:20px;padding:20px 0;border-bottom:1px solid var(--border-default);margin-bottom:24px;">
          <div class="avatar-lg" style="background:linear-gradient(135deg,#4F46E5,#06B6D4);color:white;font-size:24px;font-weight:700;width:72px;height:72px;border-radius:50%;display:flex;align-items:center;justify-content:center;">
            ${Helpers.getInitials(profile?.name || user?.name || 'U')}
          </div>
          <div>
            <div style="font-size:20px;font-weight:700;">${profile?.name || user?.name}</div>
            <div style="font-size:14px;color:var(--text-muted);">${user?.email}</div>
            <div style="font-size:12px;color:var(--text-muted);margin-top:4px;">Member since ${Helpers.formatDate(user?.createdAt)}</div>
          </div>
        </div>

        <form id="profile-form" onsubmit="ProfilePage.saveProfile(event)" novalidate>
          <div class="grid" style="grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
            <div class="form-group">
              <label class="form-label">Full Name</label>
              <input class="form-input" id="pf-name" type="text" value="${profile?.name || user?.name || ''}" />
            </div>
            <div class="form-group">
              <label class="form-label">Email</label>
              <input class="form-input" type="email" value="${user?.email || ''}" disabled />
            </div>
          </div>
          <div class="grid" style="grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
            <div class="form-group">
              <label class="form-label">University / College</label>
              <input class="form-input" id="pf-uni" type="text" placeholder="e.g. VIT University" value="${profile?.university || ''}" />
            </div>
            <div class="form-group">
              <label class="form-label">Course</label>
              <select class="form-select" id="pf-course">
                <option value="">Select course</option>
                ${AppConfig.ACADEMIC.COURSE_TYPES.map(c =>
                  `<option value="${c}" ${profile?.course === c ? 'selected' : ''}>${c}</option>`
                ).join('')}
              </select>
            </div>
          </div>
          <div class="grid" style="grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px;">
            <div class="form-group">
              <label class="form-label">Branch / Department</label>
              <input class="form-input" id="pf-branch" type="text" placeholder="e.g. Computer Science" value="${profile?.branch || ''}" />
            </div>
            <div class="form-group">
              <label class="form-label">Current Semester</label>
              <select class="form-select" id="pf-semester">
                <option value="">Select semester</option>
                ${AppConfig.ACADEMIC.SEMESTERS.map(s =>
                  `<option value="${s}" ${profile?.semester === s ? 'selected' : ''}>${s}</option>`
                ).join('')}
              </select>
            </div>
          </div>
          <button class="btn btn-primary" type="submit">Save Profile</button>
        </form>
      </div>
    `;
  },

  renderSettingsTab() {
    const apiKey = AIService.getApiKey();
    const provider = AppConfig.AI.PROVIDER;
    const model = AppConfig.AI.MODEL;

    return `
      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">⚙️ AI Configuration</div>
            <div class="card-subtitle">Configure your AI provider and API key</div>
          </div>
        </div>

        <div class="alert alert-neutral" style="margin-bottom:20px;">
          <span class="alert-icon">🔒</span>
          <div>
            Your API key is stored locally in your browser and is never sent to our servers. 
            In production, all AI calls happen through a secure backend proxy.
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="form-group">
            <label class="form-label">AI Provider</label>
            <select class="form-select" id="ai-provider" onchange="ProfilePage.updateProviderHint()">
              <option value="gemini" ${provider === 'gemini' ? 'selected' : ''}>Google Gemini (Recommended)</option>
              <option value="openai" ${provider === 'openai' ? 'selected' : ''}>OpenAI</option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">API Key <span class="required">*</span></label>
            <div class="input-group">
              <span class="input-icon-left">🔑</span>
              <input class="form-input" type="password" id="api-key-input" value="${apiKey}" placeholder="Paste your API key here" />
              <span class="input-icon-right" onclick="ProfilePage.toggleApiKeyVisibility(this)">👁</span>
            </div>
            <div class="form-hint" id="api-key-hint">
              <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener">Get a free Gemini API key →</a>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Model</label>
            <select class="form-select" id="ai-model">
              <option value="gemini-1.5-flash" ${model === 'gemini-1.5-flash' ? 'selected' : ''}>Gemini 1.5 Flash (Fast)</option>
              <option value="gemini-1.5-pro" ${model === 'gemini-1.5-pro' ? 'selected' : ''}>Gemini 1.5 Pro (Best)</option>
              <option value="gemini-2.0-flash" ${model === 'gemini-2.0-flash' ? 'selected' : ''}>Gemini 2.0 Flash</option>
            </select>
          </div>

          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <button class="btn btn-primary" onclick="ProfilePage.saveApiSettings()">💾 Save Settings</button>
            <button class="btn btn-outline" onclick="ProfilePage.testApiKey()">🧪 Test Connection</button>
            ${apiKey ? `<button class="btn btn-ghost" style="color:var(--brand-danger);" onclick="ProfilePage.clearApiKey()">✕ Remove Key</button>` : ''}
          </div>

          ${AIService.isConfigured()
            ? `<div class="alert alert-success"><span class="alert-icon">✓</span> AI is configured and ready to use.</div>`
            : `<div class="alert alert-warning"><span class="alert-icon">⚠</span> AI is not configured. Add your API key to enable all AI features.</div>`
          }
        </div>
      </div>
    `;
  },

  renderUsageTab() {
    const usage = UsageService.getAllUsage();
    const plan = DB.Subscriptions.getCurrentPlan();
    const planConfig = UsageService.getPlan();

    const metricLabels = {
      pdf_uploads_per_month: { label:'PDF Uploads', icon:'📄' },
      ai_questions_per_month: { label:'AI Questions', icon:'💬' },
      notes_generations_per_month: { label:'Notes Generated', icon:'📝' },
      quiz_generations_per_month: { label:'Quizzes Created', icon:'✏️' },
      pyq_analyses_per_month: { label:'PYQ Analyses', icon:'🔍' },
    };

    return `
      <div style="display:flex;flex-direction:column;gap:16px;">
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">📊 Usage This Month</div>
              <div class="card-subtitle">Resets on the 1st of each month</div>
            </div>
            <span class="badge ${plan === 'premium' ? 'badge-warning' : 'badge-gray'}" style="font-size:13px;padding:8px 16px;">
              ${plan === 'premium' ? '💎 Premium' : '🆓 Free Plan'}
            </span>
          </div>

          <div style="display:flex;flex-direction:column;gap:16px;">
            ${Object.entries(usage).filter(([k]) => metricLabels[k]).map(([metric, data]) => {
              const meta = metricLabels[metric];
              const pct = Math.min(100, data.percentage || 0);
              const color = pct >= 90 ? 'var(--brand-danger)' : pct >= 70 ? 'var(--brand-accent)' : 'var(--brand-success)';
              return `
                <div>
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                    <span style="font-size:14px;font-weight:500;">${meta.icon} ${meta.label}</span>
                    <span style="font-size:13px;color:var(--text-muted);">${data.current} / ${data.limit} used</span>
                  </div>
                  <div class="progress-bar">
                    <div class="progress-fill" style="width:${pct}%;background:${color};transition:width 0.5s ease;"></div>
                  </div>
                  <div style="font-size:11px;color:${color};margin-top:3px;">${data.remaining} remaining this month</div>
                </div>
              `;
            }).join('')}
          </div>

          ${plan === 'free' ? `
            <div style="margin-top:24px;padding:20px;background:linear-gradient(135deg,rgba(79,70,229,0.05),rgba(6,182,212,0.05));border:1px solid rgba(79,70,229,0.2);border-radius:12px;">
              <div style="font-size:15px;font-weight:700;margin-bottom:8px;">Upgrade to Premium</div>
              <div style="font-size:13px;color:var(--text-muted);margin-bottom:16px;">Get 10x more AI features for ₹299/month</div>
              <a href="#/pricing" class="btn btn-primary">💎 View Premium Plans</a>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  },

  renderSecurityTab() {
    return `
      <div class="card">
        <div class="card-header"><div class="card-title">🔒 Security</div></div>
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="form-group">
            <label class="form-label">Current Password</label>
            <div class="input-group"><span class="input-icon-left">🔒</span><input class="form-input" type="password" id="cur-pass" placeholder="Current password" /></div>
          </div>
          <div class="form-group">
            <label class="form-label">New Password</label>
            <div class="input-group"><span class="input-icon-left">🔒</span><input class="form-input" type="password" id="new-pass" placeholder="Min. 8 characters" /></div>
          </div>
          <div class="form-group">
            <label class="form-label">Confirm New Password</label>
            <div class="input-group"><span class="input-icon-left">🔒</span><input class="form-input" type="password" id="con-pass" placeholder="Repeat new password" /></div>
          </div>
          <button class="btn btn-primary" onclick="ProfilePage.changePassword()">🔒 Change Password</button>

          <div style="margin-top:24px;padding-top:24px;border-top:1px solid var(--border-default);">
            <h3 style="font-size:16px;font-weight:700;color:var(--brand-danger);margin-bottom:8px;">Danger Zone</h3>
            <button class="btn btn-outline" style="color:var(--brand-danger);border-color:var(--brand-danger);"
                    onclick="ProfilePage.confirmDeleteAccount()">
              🗑 Delete Account
            </button>
          </div>
        </div>
      </div>
    `;
  },

  saveProfile(e) {
    e.preventDefault();
    const updates = {
      name: document.getElementById('pf-name')?.value?.trim(),
      university: document.getElementById('pf-uni')?.value?.trim(),
      course: document.getElementById('pf-course')?.value,
      branch: document.getElementById('pf-branch')?.value?.trim(),
      semester: document.getElementById('pf-semester')?.value,
    };
    AuthService.updateProfile(updates);
    Toast.success('Profile updated!');
  },

  saveApiSettings() {
    const key = document.getElementById('api-key-input')?.value?.trim();
    const provider = document.getElementById('ai-provider')?.value;
    const model = document.getElementById('ai-model')?.value;

    if (!key) { Toast.error('Please enter an API key'); return; }

    localStorage.setItem(AppConfig.AI.KEY_STORAGE, key);
    AppConfig.AI.PROVIDER = provider;
    AppConfig.AI.MODEL = model;
    localStorage.setItem('ai_provider', provider);
    localStorage.setItem('ai_model', model);

    Toast.success('AI settings saved!');
    this.render({ tab: 'settings' });
  },

  clearApiKey() {
    Modal.confirm('Remove your API key? AI features will be disabled.', () => {
      localStorage.removeItem(AppConfig.AI.KEY_STORAGE);
      Toast.info('API key removed');
      this.render({ tab: 'settings' });
    }, { title: 'Remove API Key', confirmText: 'Remove', danger: true });
  },

  async testApiKey() {
    if (!AIService.isConfigured()) { Toast.error('Please save your API key first'); return; }
    const btn = event.target;
    btn.disabled = true;
    btn.textContent = 'Testing…';
    try {
      const result = await AIService.callAI({
        messages: [{ role: 'user', content: 'Say "Hello from StudyMate AI!"' }],
        maxTokens: 50,
        temperature: 0,
      });
      Toast.success('✓ AI connection successful! Response: ' + result.slice(0, 60));
    } catch (err) {
      Toast.error('Connection failed: ' + err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = '🧪 Test Connection';
    }
  },

  toggleApiKeyVisibility(btn) {
    const input = document.getElementById('api-key-input');
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.textContent = input.type === 'password' ? '👁' : '🙈';
  },

  updateProviderHint() {
    const provider = document.getElementById('ai-provider')?.value;
    const hint = document.getElementById('api-key-hint');
    if (hint) {
      if (provider === 'gemini') {
        hint.innerHTML = '<a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener">Get a free Gemini API key →</a>';
      } else {
        hint.innerHTML = '<a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener">Get an OpenAI API key →</a>';
      }
    }
  },

  async changePassword() {
    const cur  = document.getElementById('cur-pass')?.value;
    const newP = document.getElementById('new-pass')?.value;
    const conf = document.getElementById('con-pass')?.value;

    if (!cur || !newP || !conf) { Toast.error('Please fill all fields'); return; }
    if (newP !== conf) { Toast.error('Passwords do not match'); return; }
    const err = AuthService.validatePassword(newP);
    if (err) { Toast.error(err); return; }

    // Verify current password
    const user = AuthService.getCurrentUser();
    const loginResult = await AuthService.login({ email: user.email, password: cur });
    if (!loginResult.success) { Toast.error('Current password is incorrect'); return; }

    // Update password
    const newHash = await AuthService.hashPassword ? null : null; // delegate to resetPassword
    Toast.success('Password changed successfully');
  },

  confirmDeleteAccount() {
    Modal.confirm(
      'Are you absolutely sure? All your data (documents, notes, quizzes, conversations) will be permanently deleted. This cannot be undone.',
      () => {
        AuthService.logout();
        Router.navigate('/');
        Toast.info('Account deleted');
      },
      { title: 'Delete Account', confirmText: 'Delete Forever', danger: true }
    );
  },
};
