/**
 * StudyMate AI — Notes Generator Page
 */
window.NotesPage = {
  render() {
    const root = document.getElementById('app-root');
    const subjects = DB.Subjects.list();
    const docs = DB.Documents.list().filter(d => d.status === 'ready');
    const savedNotes = DB.Notes.list();

    root.innerHTML = AppShell.renderLayout('Notes Generator', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">📝 Notes Generator</h1>
          <p class="page-subtitle">Generate structured notes from your study material</p>
        </div>
      </div>

      <div class="grid" style="grid-template-columns:360px 1fr;gap:24px;">
        <!-- Config Panel -->
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="card">
            <div class="card-header"><div class="card-title">Generate Notes</div></div>
            <div style="display:flex;flex-direction:column;gap:14px;">
              <div class="form-group">
                <label class="form-label">Topic / Title <span class="required">*</span></label>
                <input class="form-input" type="text" id="note-topic" placeholder="e.g. Normalization in DBMS" />
              </div>
              <div class="form-group">
                <label class="form-label">Subject</label>
                <select class="form-select" id="note-subject" onchange="NotesPage.updateDocList()">
                  <option value="">All Subjects</option>
                  ${subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Source Document</label>
                <select class="form-select" id="note-doc">
                  <option value="">All Documents</option>
                  ${docs.map(d => `<option value="${d.id}">${Helpers.truncate(d.name, 40)}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Notes Type</label>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                  ${[
                    {key:'quick', label:'⚡ Quick', desc:'Bullet points'},
                    {key:'detailed', label:'📖 Detailed', desc:'Full notes'},
                    {key:'exam', label:'🎯 Exam', desc:'Exam-ready'},
                    {key:'revision', label:'↻ Revision', desc:'Key points'},
                  ].map(t => `
                    <button type="button" class="note-type-btn ${t.key === 'detailed' ? 'active' : ''}" 
                            id="note-type-${t.key}"
                            onclick="NotesPage.selectType('${t.key}')"
                            style="padding:10px;border-radius:10px;border:1.5px solid var(--border-default);cursor:pointer;text-align:left;transition:var(--transition-fast);background:var(--bg-surface);">
                      <div style="font-size:13px;font-weight:600;">${t.label}</div>
                      <div style="font-size:11px;color:var(--text-muted);">${t.desc}</div>
                    </button>
                  `).join('')}
                </div>
                <input type="hidden" id="note-type-value" value="detailed" />
              </div>
              <button class="btn btn-primary" onclick="NotesPage.generate()">
                🤖 Generate Notes
              </button>
              ${!AIService.isConfigured() ? `
                <div class="alert alert-warning" style="font-size:12px;">⚙️ <a href="#/profile?tab=settings">Configure AI key</a> first</div>
              ` : ''}
            </div>
          </div>

          <!-- Saved Notes -->
          <div class="card">
            <div class="card-header">
              <div class="card-title">Saved Notes (${savedNotes.length})</div>
            </div>
            ${savedNotes.length === 0
              ? `<div style="font-size:13px;color:var(--text-muted);text-align:center;padding:16px;">No saved notes yet</div>`
              : `<div style="display:flex;flex-direction:column;gap:8px;max-height:300px;overflow-y:auto;">
                  ${savedNotes.map(n => `
                    <div style="padding:10px;border:1px solid var(--border-default);border-radius:10px;cursor:pointer;transition:var(--transition-fast);"
                         onclick="NotesPage.loadNote('${n.id}')"
                         onmouseenter="this.style.borderColor='var(--brand-primary)'"
                         onmouseleave="this.style.borderColor='var(--border-default)'">
                      <div style="font-size:13px;font-weight:600;">${Helpers.truncate(n.title, 32)}</div>
                      <div style="font-size:11px;color:var(--text-muted);">${n.noteType} · ${Helpers.formatDate(n.createdAt)}</div>
                    </div>
                  `).join('')}
                </div>`
            }
          </div>
        </div>

        <!-- Notes Output -->
        <div class="card" id="notes-output-card">
          <div id="notes-placeholder" style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:400px;gap:16px;color:var(--text-muted);">
            <div style="font-size:64px;opacity:0.3;">📝</div>
            <div style="font-size:16px;font-weight:600;">Your notes will appear here</div>
            <div style="font-size:13px;max-width:300px;text-align:center;">Configure the options on the left and click "Generate Notes" to create AI-powered study notes.</div>
          </div>
        </div>
      </div>
    `);

    // Select default type
    setTimeout(() => this.selectType('detailed'), 50);
  },

  selectType(type) {
    document.querySelectorAll('.note-type-btn').forEach(btn => {
      btn.style.borderColor = 'var(--border-default)';
      btn.style.background = 'var(--bg-surface)';
    });
    const active = document.getElementById(`note-type-${type}`);
    if (active) {
      active.style.borderColor = 'var(--brand-primary)';
      active.style.background = 'var(--brand-primary-light)';
    }
    const hidden = document.getElementById('note-type-value');
    if (hidden) hidden.value = type;
  },

  updateDocList() {
    const subjectId = document.getElementById('note-subject')?.value;
    const docs = subjectId ? DB.Documents.list(subjectId).filter(d => d.status === 'ready') : DB.Documents.list().filter(d => d.status === 'ready');
    const select = document.getElementById('note-doc');
    if (select) {
      select.innerHTML = `<option value="">All Documents</option>` +
        docs.map(d => `<option value="${d.id}">${Helpers.truncate(d.name, 40)}</option>`).join('');
    }
  },

  async generate() {
    const topic = document.getElementById('note-topic')?.value?.trim();
    if (!topic) { Toast.error('Please enter a topic'); return; }

    const limitResult = UsageService.checkLimit('notes_generations_per_month');
    if (!limitResult.allowed) { UpgradeModal.show('notes_generations_per_month', limitResult); return; }
    if (!AIService.isConfigured()) { Toast.error('Please configure AI key in Settings'); return; }

    const docId = document.getElementById('note-doc')?.value;
    const subjectId = document.getElementById('note-subject')?.value;
    const noteType = document.getElementById('note-type-value')?.value || 'detailed';
    const subject = subjectId ? DB.Subjects.get(subjectId) : null;

    // Get relevant content via RAG
    const chunks = RAGEngine.retrieve({
      query: topic,
      documentIds: docId ? [docId] : null,
      subjectId: subjectId || null,
      topK: 8,
    });

    const content = chunks.length > 0
      ? chunks.map(c => c.text).join('\n\n')
      : (docId ? (DB.Documents.get(docId)?.content || '') : '');

    // Show loading
    const outputCard = document.getElementById('notes-output-card');
    if (outputCard) {
      outputCard.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:center;min-height:300px;gap:16px;color:var(--text-muted);">
          <div class="spinner spinner-lg"></div>
          <div>
            <div style="font-size:15px;font-weight:600;">Generating ${noteType} notes…</div>
            <div style="font-size:13px;margin-top:4px;">This may take 15-30 seconds</div>
          </div>
        </div>
      `;
    }

    try {
      const notesHtml = await AIService.generateNotes({
        topic,
        content,
        noteType,
        subjectName: subject?.name || '',
      });

      // Save note
      const note = DB.Notes.create({
        title: topic,
        content: notesHtml,
        subjectId,
        documentIds: docId ? [docId] : [],
        noteType,
        format: 'html',
      });

      UsageService.incrementUsage('notes_generations_per_month');

      if (outputCard) {
        outputCard.innerHTML = `
          <div class="card-header">
            <div>
              <div class="card-title">${topic}</div>
              <div class="card-subtitle">${noteType} notes · ${Helpers.formatDate(note.createdAt)}</div>
            </div>
            <div style="display:flex;gap:8px;">
              <button class="btn btn-sm btn-ghost" onclick="Helpers.copyToClipboard(document.getElementById('note-content').innerText)">⧉ Copy</button>
              <button class="btn btn-sm btn-outline" onclick="window.print()">🖨 Print</button>
            </div>
          </div>
          <div class="notes-editor notes-content" id="note-content" style="min-height:400px;">
            ${notesHtml}
          </div>
        `;
      }
      Toast.success('Notes generated and saved!');
    } catch (err) {
      if (outputCard) {
        outputCard.innerHTML = `
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:300px;gap:16px;">
            <div style="font-size:48px;">⚠️</div>
            <div style="font-size:15px;font-weight:600;color:var(--brand-danger);">Generation Failed</div>
            <div style="font-size:13px;color:var(--text-muted);text-align:center;max-width:400px;">${err.message}</div>
            <button class="btn btn-outline" onclick="NotesPage.generate()">↻ Try Again</button>
          </div>
        `;
      }
      Toast.error('Notes generation failed: ' + err.message);
    }
  },

  loadNote(id) {
    const note = DB.Notes.get(id);
    if (!note) return;
    const outputCard = document.getElementById('notes-output-card');
    if (outputCard) {
      outputCard.innerHTML = `
        <div class="card-header">
          <div>
            <div class="card-title">${note.title}</div>
            <div class="card-subtitle">${note.noteType} notes · ${Helpers.formatDate(note.createdAt)}</div>
          </div>
          <div style="display:flex;gap:8px;">
            <button class="btn btn-sm btn-ghost" onclick="Helpers.copyToClipboard(document.getElementById('note-content').innerText)">⧉ Copy</button>
            <button class="btn btn-sm btn-ghost" style="color:var(--brand-danger);" onclick="NotesPage.deleteNote('${note.id}')">🗑</button>
          </div>
        </div>
        <div class="notes-editor notes-content" id="note-content">${note.content}</div>
      `;
    }
  },

  deleteNote(id) {
    Modal.confirm('Delete this note?', () => {
      DB.Notes.delete(id);
      Toast.success('Note deleted');
      this.render();
    }, { title: 'Delete Note', confirmText: 'Delete', danger: true });
  },
};
