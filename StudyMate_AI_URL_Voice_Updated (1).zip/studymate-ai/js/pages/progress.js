/**
 * StudyMate AI — Progress Page
 */
window.ProgressPage = {
  render() {
    const root = document.getElementById('app-root');
    const stats = DB.Progress.getStats();
    const weakTopics = DB.Progress.getWeakTopics();
    const quizAttempts = DB.Quizzes.getAllAttempts().slice(0, 10);
    const subjects = DB.Subjects.list();

    root.innerHTML = AppShell.renderLayout('My Progress', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">📊 My Progress</h1>
          <p class="page-subtitle">Track your study activity, quiz performance, and learning progress</p>
        </div>
      </div>

      <!-- Stats -->
      <div class="grid grid-4 stagger" style="margin-bottom:24px;">
        <div class="stat-card">
          <div class="stat-card-icon stat-card-icon-primary">📄</div>
          <div>
            <div class="stat-card-value">${stats.totalDocuments}</div>
            <div class="stat-card-label">Documents</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-card-icon stat-card-icon-success">✏️</div>
          <div>
            <div class="stat-card-value">${stats.averageQuizScore}%</div>
            <div class="stat-card-label">Avg Quiz Score</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-card-icon stat-card-icon-warning">📝</div>
          <div>
            <div class="stat-card-value">${stats.totalNotes}</div>
            <div class="stat-card-label">Notes Generated</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-card-icon stat-card-icon-cyan">🃏</div>
          <div>
            <div class="stat-card-value">${stats.flashcardsLearned}/${stats.totalFlashcards}</div>
            <div class="stat-card-label">Flashcards Learned</div>
          </div>
        </div>
      </div>

      <div class="grid" style="grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px;">
        <!-- Quiz History -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">Quiz History</div>
            <a href="#/quiz" class="btn btn-sm btn-outline">+ Take Quiz</a>
          </div>
          ${quizAttempts.length === 0
            ? `<div class="empty-state" style="padding:32px 16px;"><div class="empty-state-icon">✏️</div><div class="empty-state-title">No quizzes taken yet</div><div class="empty-state-desc">Take your first quiz to see your performance analytics.</div><a href="#/quiz" class="btn btn-primary btn-sm" style="margin-top:12px;">Take a Quiz</a></div>`
            : `<div style="display:flex;flex-direction:column;gap:10px;">
                ${quizAttempts.map(attempt => {
                  const quiz = DB.Quizzes.get(attempt.quizId);
                  const color = Helpers.scoreColor(attempt.score);
                  return `
                    <div style="display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;border:1px solid var(--border-default);">
                      <div style="width:44px;height:44px;border-radius:10px;background:${color}20;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:800;color:${color};">${attempt.score}%</div>
                      <div style="flex:1;min-width:0;">
                        <div style="font-size:13px;font-weight:600;color:var(--text-primary);">${quiz ? Helpers.truncate(quiz.title, 35) : 'Quiz'}</div>
                        <div style="font-size:11px;color:var(--text-muted);">${Helpers.timeAgo(attempt.completedAt)} · ${Helpers.formatDuration(Math.round((attempt.timeTaken||0)/60))}</div>
                      </div>
                      <div class="progress-bar" style="width:60px;">
                        <div class="progress-fill" style="width:${attempt.score}%;background:${color};"></div>
                      </div>
                    </div>
                  `;
                }).join('')}
              </div>`
          }
        </div>

        <!-- Weak Topics -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">Topics Needing Practice</div>
          </div>
          ${weakTopics.length === 0
            ? `<div class="empty-state" style="padding:32px 16px;"><div class="empty-state-icon">🎯</div><div class="empty-state-title">No weak topics detected</div><div class="empty-state-desc">Great job! Take quizzes to identify areas that need more attention.</div></div>`
            : `<div style="display:flex;flex-direction:column;gap:10px;">
                ${weakTopics.map((t, i) => `
                  <div style="display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;border:1px solid var(--border-default);">
                    <div style="width:28px;height:28px;border-radius:8px;background:var(--brand-danger)15;color:var(--brand-danger);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;">${i+1}</div>
                    <div style="flex:1;">
                      <div style="font-size:13px;font-weight:600;">⚡ ${t.topic}</div>
                      <div style="font-size:11px;color:var(--text-muted);">${t.count} incorrect answer${t.count !== 1 ? 's' : ''}</div>
                    </div>
                    <button class="btn btn-sm btn-outline" onclick="AIChatPage.fillInput('Explain ${t.topic.replace(/'/g,'')}');Router.navigate('/ai-chat');">Ask AI</button>
                  </div>
                `).join('')}
              </div>`
          }
        </div>
      </div>

      <!-- Subject Progress -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">Subject Activity</div>
        </div>
        ${subjects.length === 0
          ? `<div class="empty-state" style="padding:32px;"><div class="empty-state-icon">📚</div><div class="empty-state-title">No subjects</div><a href="#/subjects" class="btn btn-primary btn-sm" style="margin-top:12px;">+ Add Subjects</a></div>`
          : `<div class="grid grid-3" style="gap:14px;">
              ${subjects.map(sub => {
                const subDocs = DB.Documents.list(sub.id);
                const subNotes = DB.Notes.list(sub.id);
                const subDecks = DB.Flashcards.listDecks(sub.id);
                return `
                  <div style="padding:16px;border:1px solid var(--border-default);border-radius:12px;position:relative;overflow:hidden;">
                    <div style="position:absolute;top:0;left:0;right:0;height:3px;background:${sub.color};"></div>
                    <div style="font-size:14px;font-weight:700;margin-bottom:8px;">${Helpers.truncate(sub.name, 28)}</div>
                    <div style="display:flex;gap:12px;font-size:12px;color:var(--text-muted);">
                      <span>📄 ${subDocs.length}</span>
                      <span>📝 ${subNotes.length}</span>
                      <span>🃏 ${subDecks.length}</span>
                    </div>
                  </div>
                `;
              }).join('')}
            </div>`
        }
      </div>
    `);
  },
};

/**
 * StudyMate AI — Exam Mode Page
 */
window.ExamModePage = {
  examTimer: null,
  examQuiz: null,
  currentQ: 0,
  answers: {},
  examDuration: 0,
  timeLeft: 0,
  examStarted: false,

  render() {
    const root = document.getElementById('app-root');
    const docs = DB.Documents.list().filter(d => d.status === 'ready');
    const subjects = DB.Subjects.list();

    root.innerHTML = AppShell.renderLayout('Exam Mode', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">⏱️ Exam Mode</h1>
          <p class="page-subtitle">Practice timed exams under real exam conditions. No hints, no breaks.</p>
        </div>
      </div>

      <div style="max-width:680px;margin:0 auto;">
        <div class="card">
          <div style="text-align:center;padding:16px 0 32px;">
            <div style="font-size:64px;margin-bottom:16px;">⏱️</div>
            <h2 style="font-size:24px;font-weight:800;margin-bottom:8px;">Configure Your Exam</h2>
            <p style="font-size:14px;color:var(--text-muted);max-width:400px;margin:0 auto;">Generate a timed practice exam from your study material with realistic exam conditions.</p>
          </div>

          <div style="display:flex;flex-direction:column;gap:16px;max-width:460px;margin:0 auto;">
            <div class="form-group">
              <label class="form-label">Exam Topic <span class="required">*</span></label>
              <input class="form-input" id="exam-topic" type="text" placeholder="e.g. Complete DBMS Syllabus" />
            </div>
            <div class="form-group">
              <label class="form-label">Source Document</label>
              <select class="form-select" id="exam-doc">
                <option value="">All documents</option>
                ${docs.map(d => `<option value="${d.id}">${Helpers.truncate(d.name,40)}</option>`).join('')}
              </select>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">
              <div class="form-group">
                <label class="form-label">Questions</label>
                <select class="form-select" id="exam-count">
                  <option value="10">10</option>
                  <option value="20" selected>20</option>
                  <option value="30">30</option>
                  <option value="50">50</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Duration</label>
                <select class="form-select" id="exam-duration">
                  <option value="30">30 min</option>
                  <option value="60" selected>60 min</option>
                  <option value="90">90 min</option>
                  <option value="120">2 hours</option>
                  <option value="180">3 hours</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Difficulty</label>
                <select class="form-select" id="exam-difficulty">
                  <option value="easy">Easy</option>
                  <option value="medium" selected>Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
            </div>

            <div style="background:rgba(79,70,229,0.05);border:1px solid rgba(79,70,229,0.2);border-radius:12px;padding:16px;">
              <div style="font-size:13px;font-weight:600;margin-bottom:8px;">📋 Exam Mode Rules:</div>
              <ul style="font-size:12px;color:var(--text-muted);padding-left:16px;line-height:1.8;">
                <li>Timer starts automatically when exam begins</li>
                <li>No hints or explanations during the exam</li>
                <li>Auto-submits when time runs out</li>
                <li>Results and analysis shown after submission</li>
              </ul>
            </div>

            <button class="btn btn-primary btn-lg" onclick="ExamModePage.startExam()" style="width:100%;margin-top:8px;">
              ⏱️ Start Timed Exam
            </button>
          </div>
        </div>
      </div>
    `);
  },

  async startExam() {
    const topic = document.getElementById('exam-topic')?.value?.trim();
    if (!topic) { Toast.error('Please enter an exam topic'); return; }
    if (!AIService.isConfigured()) { Toast.error('Please configure AI key in Settings'); return; }

    const docId = document.getElementById('exam-doc')?.value;
    const count = parseInt(document.getElementById('exam-count')?.value || '20');
    const durationMins = parseInt(document.getElementById('exam-duration')?.value || '60');
    const difficulty = document.getElementById('exam-difficulty')?.value || 'medium';

    const limitResult = UsageService.checkLimit('quiz_generations_per_month');
    if (!limitResult.allowed) { UpgradeModal.show('quiz_generations_per_month', limitResult); return; }

    const chunks = RAGEngine.retrieve({ query: topic, documentIds: docId ? [docId] : null, topK: 10 });
    const content = chunks.length > 0 ? chunks.map(c => c.text).join('\n\n') : topic;

    const root = document.getElementById('app-root');
    root.innerHTML = `
      <div class="exam-mode-screen">
        <div style="text-align:center;color:white;padding:40px;">
          <div class="spinner spinner-xl" style="margin:0 auto 20px;border-color:rgba(255,255,255,0.3);border-top-color:white;"></div>
          <div style="font-size:18px;font-weight:600;">Generating Exam…</div>
          <div style="font-size:13px;opacity:0.7;margin-top:8px;">Creating ${count} ${difficulty} questions on "${topic}"</div>
        </div>
      </div>
    `;

    try {
      const questions = await AIService.generateQuiz({ topic, content, count, difficulty, quizType: 'mcq' });
      UsageService.incrementUsage('quiz_generations_per_month');

      this.examQuiz = { questions, title: topic };
      this.currentQ = 0;
      this.answers = {};
      this.examDuration = durationMins * 60;
      this.timeLeft = this.examDuration;
      this.examStarted = true;

      clearInterval(this.examTimer);
      this.examTimer = setInterval(() => {
        this.timeLeft--;
        this.updateExamTimer();
        if (this.timeLeft <= 0) {
          clearInterval(this.examTimer);
          this.submitExam();
        }
      }, 1000);

      this.renderExamScreen();
    } catch (err) {
      this.render();
      Toast.error('Could not start exam: ' + err.message);
    }
  },

  renderExamScreen() {
    const root = document.getElementById('app-root');
    const q = this.examQuiz.questions[this.currentQ];
    const total = this.examQuiz.questions.length;
    const mins = Math.floor(this.timeLeft / 60);
    const secs = this.timeLeft % 60;
    const timerClass = this.timeLeft < 300 ? 'style="color:#EF4444;"' : this.timeLeft < 600 ? 'style="color:#F59E0B;"' : '';
    const optionLetters = ['A','B','C','D'];

    root.innerHTML = `
      <div class="exam-mode-screen">
        <!-- Exam Header -->
        <div class="exam-header">
          <div style="font-size:14px;font-weight:600;color:white;">${this.examQuiz.title}</div>
          <div style="display:flex;gap:16px;align-items:center;">
            <div style="font-size:13px;color:rgba(255,255,255,0.7);">Q ${this.currentQ+1}/${total}</div>
            <div class="exam-timer" id="exam-timer" ${timerClass}>${mins}:${secs.toString().padStart(2,'0')}</div>
          </div>
          <button class="btn btn-danger btn-sm" onclick="ExamModePage.submitExam()">Submit Exam</button>
        </div>

        <!-- Progress -->
        <div class="exam-progress">
          <div class="progress-bar" style="border-radius:0;height:4px;background:rgba(255,255,255,0.1);">
            <div class="progress-fill" style="width:${((this.currentQ+1)/total*100).toFixed(1)}%;border-radius:0;"></div>
          </div>
        </div>

        <!-- Question Area -->
        <div class="exam-content">
          <!-- Question Nav -->
          <div class="exam-question-nav">
            ${this.examQuiz.questions.map((_, i) => `
              <button class="exam-q-btn ${i === this.currentQ ? 'current' : this.answers[i] !== undefined ? 'answered' : ''}"
                      onclick="ExamModePage.goTo(${i})">${i+1}</button>
            `).join('')}
          </div>

          <!-- Question -->
          <div style="background:white;border-radius:16px;padding:32px;flex:1;">
            <div style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;color:var(--text-muted);margin-bottom:12px;">
              Question ${this.currentQ+1} · ${q.topic || 'General'}
            </div>
            <div style="font-size:18px;font-weight:600;color:var(--text-primary);margin-bottom:28px;line-height:1.5;">${q.question}</div>
            <div style="display:flex;flex-direction:column;gap:10px;">
              ${(q.options || []).map((opt, i) => {
                const selected = this.answers[this.currentQ] === i;
                return `
                  <button class="quiz-option ${selected ? 'selected' : ''}"
                          style="padding:14px 18px;font-size:15px;"
                          onclick="ExamModePage.answer(${i})">
                    <span class="quiz-option-letter">${optionLetters[i]}</span>
                    <span>${opt}</span>
                  </button>
                `;
              }).join('')}
            </div>

            <div style="display:flex;justify-content:space-between;margin-top:32px;">
              <button class="btn btn-outline" onclick="ExamModePage.goTo(${this.currentQ - 1})" ${this.currentQ === 0 ? 'disabled' : ''}>← Previous</button>
              ${this.currentQ < total - 1
                ? `<button class="btn btn-primary" onclick="ExamModePage.goTo(${this.currentQ + 1})">Next →</button>`
                : `<button class="btn btn-success" onclick="ExamModePage.submitExam()">Submit Exam ✓</button>`
              }
            </div>
          </div>
        </div>
      </div>
    `;
  },

  answer(index) {
    this.answers[this.currentQ] = index;
    document.querySelectorAll('.quiz-option').forEach((btn, i) => {
      btn.classList.toggle('selected', i === index);
    });
  },

  goTo(index) {
    const q = this.examQuiz.questions;
    if (index < 0 || index >= q.length) return;
    this.currentQ = index;
    this.renderExamScreen();
  },

  updateExamTimer() {
    const el = document.getElementById('exam-timer');
    if (!el) return;
    const mins = Math.floor(this.timeLeft / 60);
    const secs = this.timeLeft % 60;
    el.textContent = `${mins}:${secs.toString().padStart(2,'0')}`;
    if (this.timeLeft < 300) el.style.color = '#EF4444';
    else if (this.timeLeft < 600) el.style.color = '#F59E0B';
  },

  submitExam() {
    clearInterval(this.examTimer);
    const q = this.examQuiz.questions;
    let correct = 0;
    const incorrect = [];

    q.forEach((question, i) => {
      if (this.answers[i] === question.correct) correct++;
      else incorrect.push({ ...question, userAnswer: this.answers[i] });
    });

    const score = Math.round((correct / q.length) * 100);
    const timeTaken = this.examDuration - this.timeLeft;

    const root = document.getElementById('app-root');
    const color = score >= 80 ? '#10B981' : score >= 60 ? '#F59E0B' : '#EF4444';
    const emoji = score >= 80 ? '🏆' : score >= 60 ? '👍' : '📚';

    root.innerHTML = `
      <div class="exam-mode-screen" style="display:flex;align-items:center;justify-content:center;">
        <div class="card" style="max-width:600px;width:100%;padding:48px;text-align:center;">
          <div style="font-size:72px;margin-bottom:20px;">${emoji}</div>
          <h2 style="font-size:48px;font-weight:900;color:${color};margin-bottom:8px;">${score}%</h2>
          <div style="font-size:16px;color:var(--text-muted);margin-bottom:32px;">${correct}/${q.length} correct · Time: ${Helpers.formatDuration(Math.round(timeTaken/60))}</div>

          <div class="grid grid-3" style="margin-bottom:32px;gap:16px;">
            <div class="stat-card"><div style="font-size:22px;font-weight:800;color:var(--brand-success);">${correct}</div><div style="font-size:12px;">Correct</div></div>
            <div class="stat-card"><div style="font-size:22px;font-weight:800;color:var(--brand-danger);">${q.length - correct}</div><div style="font-size:12px;">Incorrect</div></div>
            <div class="stat-card"><div style="font-size:22px;font-weight:800;color:var(--brand-accent);">${q.length - Object.keys(this.answers).length}</div><div style="font-size:12px;">Skipped</div></div>
          </div>

          ${incorrect.length > 0 ? `
            <div style="text-align:left;margin-bottom:24px;">
              <h3 style="font-size:14px;font-weight:700;margin-bottom:8px;">Review Incorrect:</h3>
              <div style="display:flex;flex-direction:column;gap:8px;max-height:250px;overflow-y:auto;">
                ${incorrect.slice(0,5).map((q,i) => `
                  <div style="padding:12px;background:var(--bg-raised);border-radius:10px;text-align:left;">
                    <div style="font-size:13px;font-weight:600;margin-bottom:4px;">${q.question}</div>
                    <div style="font-size:12px;color:var(--brand-success);">✓ ${q.options?.[q.correct]}</div>
                    ${q.userAnswer !== undefined ? `<div style="font-size:12px;color:var(--brand-danger);">✗ ${q.options?.[q.userAnswer] || 'Skipped'}</div>` : ''}
                    ${q.explanation ? `<div style="font-size:11px;color:var(--text-muted);margin-top:4px;">${q.explanation}</div>` : ''}
                  </div>
                `).join('')}
              </div>
            </div>
          ` : ''}

          <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
            <button class="btn btn-outline" onclick="ExamModePage.render()">← Back to Setup</button>
            <a href="#/dashboard" class="btn btn-primary">🏠 Dashboard</a>
            <a href="#/progress" class="btn btn-ghost">📊 View Progress</a>
          </div>
        </div>
      </div>
    `;
  },
};
