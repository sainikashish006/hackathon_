/**
 * StudyMate AI — Register Page
 */
window.RegisterPage = {
  render() {
    const root = document.getElementById('app-root');
    if (!root) return;
    root.innerHTML = `
      <div class="auth-layout">
        <div class="auth-panel-left" style="background:linear-gradient(135deg,#4F46E5 0%,#7C3AED 60%,#06B6D4 100%);">
          <div style="text-align:center;color:white;max-width:380px;">
            <div style="font-size:72px;margin-bottom:24px;">🎓</div>
            <h1 style="font-size:32px;font-weight:900;color:white;margin-bottom:16px;letter-spacing:-0.03em;">Start studying smarter</h1>
            <p style="font-size:16px;opacity:0.85;line-height:1.7;">Upload your study material and let AI help you prepare for exams — for free.</p>
            <div style="background:rgba(255,255,255,0.1);border-radius:16px;padding:24px;margin-top:32px;text-align:left;">
              <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;opacity:0.7;margin-bottom:16px;">Free Plan Includes</div>
              ${['5 PDF uploads/month','50 AI questions/month','Notes & quiz generation','PYQ analysis','Study planner','Flashcards'].map(f =>
                `<div style="display:flex;align-items:center;gap:10px;font-size:14px;opacity:0.9;margin-bottom:8px;"><span style="color:#10B981;font-weight:700;">✓</span>${f}</div>`
              ).join('')}
            </div>
          </div>
        </div>

        <div class="auth-panel-right">
          <div class="auth-form">
            <div class="auth-logo">
              <div class="auth-logo-icon">📚</div>
              <div class="auth-logo-name">StudyMate <strong>AI</strong></div>
            </div>

            <h2 class="auth-heading">Create your account</h2>
            <p class="auth-subheading">Already have an account? <a href="#/login">Log in</a></p>

            <div id="reg-error" style="display:none;" class="alert alert-danger">
              <span class="alert-icon">⚠</span>
              <span id="reg-error-text"></span>
            </div>

            <form id="register-form" onsubmit="RegisterPage.handleSubmit(event)" novalidate>
              <div style="display:flex;flex-direction:column;gap:16px;">
                <div class="form-group">
                  <label class="form-label" for="reg-name">Full Name <span class="required">*</span></label>
                  <div class="input-group">
                    <span class="input-icon-left">👤</span>
                    <input class="form-input" type="text" id="reg-name" placeholder="Your full name" required autocomplete="name" />
                  </div>
                </div>

                <div class="form-group">
                  <label class="form-label" for="reg-email">Email Address <span class="required">*</span></label>
                  <div class="input-group">
                    <span class="input-icon-left">✉</span>
                    <input class="form-input" type="email" id="reg-email" placeholder="your@email.com" required autocomplete="email" />
                  </div>
                </div>

                <div class="form-group">
                  <label class="form-label" for="reg-course">Course</label>
                  <select class="form-select" id="reg-course">
                    <option value="">Select your course</option>
                    ${AppConfig.ACADEMIC.COURSE_TYPES.map(c => `<option value="${c}">${c}</option>`).join('')}
                  </select>
                </div>

                <div class="form-group">
                  <label class="form-label" for="reg-password">Password <span class="required">*</span></label>
                  <div class="input-group">
                    <span class="input-icon-left">🔒</span>
                    <input class="form-input" type="password" id="reg-password" placeholder="Min. 8 characters" required autocomplete="new-password" />
                    <span class="input-icon-right" onclick="RegisterPage.togglePassword('reg-password', this)">👁</span>
                  </div>
                  <span class="form-hint">At least 8 characters with a letter and number</span>
                </div>

                <div class="form-group">
                  <label class="form-label" for="reg-confirm">Confirm Password <span class="required">*</span></label>
                  <div class="input-group">
                    <span class="input-icon-left">🔒</span>
                    <input class="form-input" type="password" id="reg-confirm" placeholder="Repeat your password" required autocomplete="new-password" />
                  </div>
                </div>

                <div class="form-check">
                  <input type="checkbox" id="reg-terms" required />
                  <label class="form-check-label" for="reg-terms">
                    I agree to the <a href="#/help">Terms of Service</a>
                  </label>
                </div>

                <button class="btn btn-primary btn-lg" type="submit" id="reg-submit" style="width:100%;margin-top:4px;">
                  🚀 Create Account — It's Free
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    `;
  },

  togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.textContent = input.type === 'password' ? '👁' : '🙈';
  },

  showError(msg) {
    const el = document.getElementById('reg-error');
    const txt = document.getElementById('reg-error-text');
    if (el && txt) { txt.textContent = msg; el.style.display = 'flex'; }
  },

  async handleSubmit(e) {
    e.preventDefault();
    const name     = document.getElementById('reg-name')?.value?.trim();
    const email    = document.getElementById('reg-email')?.value?.trim();
    const course   = document.getElementById('reg-course')?.value;
    const password = document.getElementById('reg-password')?.value;
    const confirm  = document.getElementById('reg-confirm')?.value;
    const terms    = document.getElementById('reg-terms')?.checked;
    const submitBtn= document.getElementById('reg-submit');

    document.getElementById('reg-error').style.display = 'none';

    if (!terms) { this.showError('Please agree to the Terms of Service'); return; }
    if (password !== confirm) { this.showError('Passwords do not match'); return; }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating account…';

    const result = await AuthService.register({ name, email, password, course });

    if (result.success) {
      Toast.success(`Welcome to StudyMate AI, ${name.split(' ')[0]}! 🎉`);
      Router.navigate('/profile');
    } else {
      this.showError(result.error || 'Registration failed. Please try again.');
      submitBtn.disabled = false;
      submitBtn.textContent = '🚀 Create Account — It\'s Free';
    }
  },
};

/**
 * Forgot Password Page
 */
window.ForgotPasswordPage = {
  render() {
    const root = document.getElementById('app-root');
    if (!root) return;
    root.innerHTML = `
      <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg-raised);padding:24px;">
        <div class="card" style="max-width:440px;width:100%;padding:40px;">
          <div style="text-align:center;margin-bottom:32px;">
            <a href="#/login" style="display:flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;margin-bottom:24px;">
              <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#4F46E5,#06B6D4);display:flex;align-items:center;justify-content:center;font-size:18px;color:white;">📚</div>
              <span style="font-size:18px;font-weight:700;color:var(--text-primary);">StudyMate AI</span>
            </a>
            <div style="font-size:48px;margin-bottom:16px;">🔑</div>
            <h2 style="font-size:24px;font-weight:800;margin-bottom:8px;">Reset your password</h2>
            <p style="font-size:14px;color:var(--text-muted);">Enter your email and we'll send a reset link.</p>
          </div>

          <div id="fp-success" style="display:none;" class="alert alert-success">
            <span class="alert-icon">✓</span>
            <span id="fp-success-text"></span>
          </div>
          <div id="fp-error" style="display:none;" class="alert alert-danger">
            <span class="alert-icon">⚠</span>
            <span id="fp-error-text"></span>
          </div>

          <form id="fp-form" onsubmit="ForgotPasswordPage.handleSubmit(event)">
            <div class="form-group" style="margin-bottom:20px;">
              <label class="form-label" for="fp-email">Email Address</label>
              <div class="input-group">
                <span class="input-icon-left">✉</span>
                <input class="form-input" type="email" id="fp-email" placeholder="your@email.com" required />
              </div>
            </div>
            <button class="btn btn-primary btn-lg" type="submit" id="fp-submit" style="width:100%;">
              Send Reset Link
            </button>
          </form>

          <div style="text-align:center;margin-top:20px;">
            <a href="#/login" style="font-size:13px;color:var(--text-muted);">← Back to Login</a>
          </div>
        </div>
      </div>
    `;
  },

  async handleSubmit(e) {
    e.preventDefault();
    const email = document.getElementById('fp-email')?.value?.trim();
    const submit = document.getElementById('fp-submit');
    const errorEl = document.getElementById('fp-error');
    const successEl = document.getElementById('fp-success');

    errorEl.style.display = 'none';
    successEl.style.display = 'none';

    if (!AuthService.validateEmail(email)) {
      document.getElementById('fp-error-text').textContent = 'Please enter a valid email address';
      errorEl.style.display = 'flex';
      return;
    }

    submit.disabled = true;
    submit.textContent = 'Sending…';

    const result = AuthService.requestPasswordReset(email);
    if (result.success) {
      document.getElementById('fp-success-text').textContent =
        'In production, a password reset link would be sent to your email. Demo token (for testing): ' + result.token;
      successEl.style.display = 'flex';
      submit.style.display = 'none';
    } else {
      document.getElementById('fp-error-text').textContent = result.error;
      errorEl.style.display = 'flex';
      submit.disabled = false;
      submit.textContent = 'Send Reset Link';
    }
  },
};
