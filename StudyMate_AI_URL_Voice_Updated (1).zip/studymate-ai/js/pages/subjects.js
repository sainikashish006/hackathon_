/**
 * StudyMate AI — Subjects Page
 */
window.SubjectsPage = {
  render() {
    const root = document.getElementById('app-root');
    const subjects = DB.Subjects.list();
    const colors = AppConfig.ACADEMIC.DEFAULT_SUBJECT_COLORS;

    root.innerHTML = AppShell.renderLayout('My Subjects', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">My Subjects</h1>
          <p class="page-subtitle">Organize your study material by subject and semester</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="SubjectsPage.showAddModal()">+ Add Subject</button>
        </div>
      </div>

      ${subjects.length === 0
        ? `<div class="empty-state">
            <div class="empty-state-icon">📚</div>
            <div class="empty-state-title">No subjects yet</div>
            <div class="empty-state-desc">Create your first subject to start organizing your study material by course, semester, and unit.</div>
            <button class="btn btn-primary" onclick="SubjectsPage.showAddModal()">+ Add Your First Subject</button>
           </div>`
        : `<div class="grid grid-auto stagger">
            ${subjects.map(sub => `
              <div class="card card-hover" style="cursor:pointer;position:relative;overflow:hidden;"
                   onclick="Router.navigate('/subjects?id=${sub.id}')">
                <div style="position:absolute;top:0;left:0;right:0;height:4px;background:${sub.color};"></div>
                <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-top:8px;">
                  <div style="width:48px;height:48px;border-radius:12px;background:${sub.color}20;display:flex;align-items:center;justify-content:center;font-size:22px;">📚</div>
                  <div style="display:flex;gap:4px;" onclick="event.stopPropagation()">
                    <button class="btn btn-icon-sm btn-ghost" onclick="SubjectsPage.showEditModal('${sub.id}')" title="Edit">✏</button>
                    <button class="btn btn-icon-sm btn-ghost" onclick="SubjectsPage.confirmDelete('${sub.id}','${sub.name.replace(/'/g,'')}')" title="Delete" style="color:var(--brand-danger);">🗑</button>
                  </div>
                </div>
                <div style="margin-top:14px;">
                  <div style="font-size:16px;font-weight:700;color:var(--text-primary);margin-bottom:4px;">${sub.name}</div>
                  <div style="font-size:12px;color:var(--text-muted);">${sub.code ? sub.code + ' · ' : ''}${sub.semester || 'No semester'}</div>
                  ${sub.description ? `<div style="font-size:12px;color:var(--text-secondary);margin-top:6px;">${Helpers.truncate(sub.description, 60)}</div>` : ''}
                </div>
                <div style="display:flex;gap:16px;margin-top:16px;padding-top:14px;border-top:1px solid var(--border-default);">
                  <div style="font-size:12px;color:var(--text-muted);">📄 ${sub.documentCount || 0} documents</div>
                  <div style="font-size:12px;color:var(--text-muted);">📅 ${Helpers.formatDate(sub.createdAt)}</div>
                </div>
              </div>
            `).join('')}
          </div>`
      }
    `);
  },

  showAddModal() {
    const colors = AppConfig.ACADEMIC.DEFAULT_SUBJECT_COLORS;
    const semesters = AppConfig.ACADEMIC.SEMESTERS;
    Modal.show(`
      <div class="modal-header">
        <h3 class="modal-title">Add New Subject</h3>
        <button class="modal-close" onclick="Modal.close()">✕</button>
      </div>
      <div class="modal-body">
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="form-group">
            <label class="form-label">Subject Name <span class="required">*</span></label>
            <input class="form-input" type="text" id="sub-name" placeholder="e.g. Data Structures & Algorithms" />
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
            <div class="form-group">
              <label class="form-label">Subject Code</label>
              <input class="form-input" type="text" id="sub-code" placeholder="e.g. CSE-201" />
            </div>
            <div class="form-group">
              <label class="form-label">Semester</label>
              <select class="form-select" id="sub-semester">
                <option value="">Select semester</option>
                ${semesters.map(s => `<option value="${s}">${s}</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Description</label>
            <textarea class="form-textarea" id="sub-desc" rows="2" placeholder="Optional description"></textarea>
          </div>
          <div class="form-group">
            <label class="form-label">Color</label>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
              ${colors.map((c, i) => `
                <button type="button" id="color-${i}" style="width:32px;height:32px;border-radius:8px;background:${c};border:3px solid transparent;cursor:pointer;transition:var(--transition-fast);"
                        onclick="SubjectsPage.selectColor('${c}', ${i})" class="color-btn"></button>
              `).join('')}
            </div>
          </div>
          <input type="hidden" id="sub-color" value="${colors[0]}" />
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>
        <button class="btn btn-primary" onclick="SubjectsPage.createSubject()">Create Subject</button>
      </div>
    `);
    // Select first color
    setTimeout(() => {
      const btn = document.getElementById('color-0');
      if (btn) btn.style.border = '3px solid var(--text-primary)';
    }, 50);
  },

  selectColor(color, index) {
    document.getElementById('sub-color').value = color;
    document.querySelectorAll('.color-btn').forEach((btn, i) => {
      btn.style.border = i === index ? '3px solid var(--text-primary)' : '3px solid transparent';
    });
  },

  createSubject() {
    const name = document.getElementById('sub-name')?.value?.trim();
    const code = document.getElementById('sub-code')?.value?.trim();
    const semester = document.getElementById('sub-semester')?.value;
    const desc = document.getElementById('sub-desc')?.value?.trim();
    const color = document.getElementById('sub-color')?.value || AppConfig.ACADEMIC.DEFAULT_SUBJECT_COLORS[0];

    if (!name) { Toast.error('Subject name is required'); return; }

    DB.Subjects.create({ name, code, semester, description: desc, color });
    Modal.close();
    Toast.success(`Subject "${name}" created!`);
    this.render();
  },

  showEditModal(id) {
    const sub = DB.Subjects.get(id);
    if (!sub) return;
    const colors = AppConfig.ACADEMIC.DEFAULT_SUBJECT_COLORS;
    const semesters = AppConfig.ACADEMIC.SEMESTERS;

    Modal.show(`
      <div class="modal-header">
        <h3 class="modal-title">Edit Subject</h3>
        <button class="modal-close" onclick="Modal.close()">✕</button>
      </div>
      <div class="modal-body">
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="form-group">
            <label class="form-label">Subject Name <span class="required">*</span></label>
            <input class="form-input" type="text" id="edit-sub-name" value="${sub.name}" />
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
            <div class="form-group">
              <label class="form-label">Subject Code</label>
              <input class="form-input" type="text" id="edit-sub-code" value="${sub.code || ''}" />
            </div>
            <div class="form-group">
              <label class="form-label">Semester</label>
              <select class="form-select" id="edit-sub-semester">
                <option value="">Select semester</option>
                ${semesters.map(s => `<option value="${s}" ${sub.semester === s ? 'selected' : ''}>${s}</option>`).join('')}
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Description</label>
            <textarea class="form-textarea" id="edit-sub-desc" rows="2">${sub.description || ''}</textarea>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="Modal.close()">Cancel</button>
        <button class="btn btn-primary" onclick="SubjectsPage.updateSubject('${id}')">Save Changes</button>
      </div>
    `);
  },

  updateSubject(id) {
    const name = document.getElementById('edit-sub-name')?.value?.trim();
    if (!name) { Toast.error('Subject name is required'); return; }
    DB.Subjects.update(id, {
      name,
      code: document.getElementById('edit-sub-code')?.value?.trim(),
      semester: document.getElementById('edit-sub-semester')?.value,
      description: document.getElementById('edit-sub-desc')?.value?.trim(),
    });
    Modal.close();
    Toast.success('Subject updated');
    this.render();
  },

  confirmDelete(id, name) {
    Modal.confirm(
      `Delete subject "${name}"? This will also delete all documents in this subject. This cannot be undone.`,
      () => {
        DB.Subjects.delete(id);
        Toast.success('Subject deleted');
        this.render();
      },
      { title: 'Delete Subject', confirmText: 'Delete', danger: true }
    );
  },
};
