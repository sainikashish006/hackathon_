/**
 * StudyMate AI — Documents Page
 */
window.DocumentsPage = {
  render(params = {}) {
    const root = document.getElementById('app-root');
    const subjects = DB.Subjects.list();
    const filterSubjectId = params.subject || null;
    const docs = DB.Documents.list(filterSubjectId);

    root.innerHTML = AppShell.renderLayout('My Documents', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">My Documents</h1>
          <p class="page-subtitle">Manage your uploaded study material</p>
        </div>
        <div class="page-actions">
          <select class="form-select" style="min-width:180px;" onchange="Router.navigate('/documents?subject='+this.value)">
            <option value="">All Subjects</option>
            ${subjects.map(s => `<option value="${s.id}" ${filterSubjectId === s.id ? 'selected' : ''}>${s.name}</option>`).join('')}
          </select>
        </div>
      </div>

      <!-- Upload Area -->
      <div class="card" style="margin-bottom:24px;">
        <div class="card-header">
          <div class="card-title">⬆️ Upload Documents</div>
          <div style="display:flex;align-items:center;gap:8px;">
            ${subjects.length > 0 ? `
              <select class="form-select form-select-sm" id="upload-subject-select" style="min-width:160px;font-size:12px;padding:6px 10px;">
                <option value="">No Subject</option>
                ${subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('')}
              </select>
            ` : '<a href="#/subjects" class="btn btn-sm btn-ghost" style="font-size:12px;">Create a subject first</a>'}
          </div>
        </div>
        <div id="upload-container">
          ${DocumentUploaderComponent.render('documents', {
            subjectId: null,
            onComplete: 'DocumentsPage.onUploadComplete',
          })}
        </div>
        <div class="ai-disclaimer" style="margin-top:12px;">
          <span class="ai-disclaimer-icon">ℹ</span>
          <span>Supported formats: PDF, TXT, DOCX · Max ${UsageService.getPlan().limits.max_file_size_mb}MB per file · Uploads remaining this month: ${UsageService.checkLimit('pdf_uploads_per_month').remaining}</span>
        </div>
      </div>

      <!-- Documents List -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">📄 Documents (${docs.length})</div>
          <div style="display:flex;gap:8px;">
            <input type="text" class="form-input" style="max-width:200px;" placeholder="Search documents…"
                   oninput="DocumentsPage.filterDocs(this.value)" id="doc-search" />
          </div>
        </div>

        <div id="docs-list">
          ${this.renderDocsList(docs)}
        </div>
      </div>
    `);

    // Attach drag/drop handlers
    this.initDragDrop();
  },

  renderDocsList(docs) {
    if (docs.length === 0) {
      return `<div class="empty-state">
        <div class="empty-state-icon">📄</div>
        <div class="empty-state-title">No documents yet</div>
        <div class="empty-state-desc">Upload your first PDF, TXT, or DOCX file to start using AI study features.</div>
      </div>`;
    }

    return `<div style="display:flex;flex-direction:column;gap:10px;">
      ${docs.map(doc => this.renderDocItem(doc)).join('')}
    </div>`;
  },

  renderDocItem(doc) {
    const subjects = DB.Subjects.list();
    const subject = subjects.find(s => s.id === doc.subjectId);
    const statusMap = { ready: 'success', processing: 'warning', failed: 'danger' };
    const statusIcon = { ready: '✓', processing: '⟳', failed: '✕' };
    const fileIcon = doc.name?.endsWith('.pdf') ? '📑' : doc.name?.endsWith('.docx') ? '📃' : '📄';

    return `
      <div class="doc-item" id="doc-item-${doc.id}">
        <div class="doc-icon ${doc.name?.endsWith('.pdf') ? 'doc-icon-pdf' : doc.name?.endsWith('.docx') ? 'doc-icon-docx' : 'doc-icon-txt'}">
          ${fileIcon}
        </div>
        <div class="doc-info">
          <div class="doc-name">${doc.name}</div>
          <div class="doc-meta">
            <span class="badge badge-${statusMap[doc.status] || 'gray'}" style="font-size:10px;">
              ${statusIcon[doc.status] || '?'} ${doc.status}
            </span>
            ${subject ? `· <span style="color:${subject.color}">${subject.name}</span>` : ''}
            ${doc.chunkCount ? `· ${doc.chunkCount} chunks` : ''}
            ${doc.pageCount ? `· ${doc.pageCount} pages` : ''}
            · ${Helpers.fileSize(doc.fileSize)}
            · ${Helpers.timeAgo(doc.createdAt)}
          </div>
          ${doc.processingError ? `<div style="font-size:11px;color:var(--brand-danger);margin-top:3px;">⚠ ${doc.processingError}</div>` : ''}
        </div>
        <div style="display:flex;gap:6px;flex-shrink:0;">
          ${doc.status === 'ready' ? `
            <button class="btn btn-sm btn-outline" onclick="Router.navigate('/ai-chat?docId=${doc.id}')" title="Ask AI about this document">💬 Ask AI</button>
          ` : ''}
          ${doc.status === 'failed' ? `
            <button class="btn btn-sm btn-outline" onclick="DocumentsPage.retryDoc('${doc.id}')" style="color:var(--brand-warning);">↻ Retry</button>
          ` : ''}
          <button class="btn btn-icon-sm btn-ghost" onclick="DocumentsPage.confirmDeleteDoc('${doc.id}','${doc.name.replace(/'/g,'')}')">🗑</button>
        </div>
      </div>
    `;
  },

  filterDocs: Helpers.debounce(function(query) {
    const docs = DB.Documents.list();
    const filtered = query
      ? docs.filter(d => d.name.toLowerCase().includes(query.toLowerCase()))
      : docs;
    const listEl = document.getElementById('docs-list');
    if (listEl) listEl.innerHTML = DocumentsPage.renderDocsList(filtered);
  }, 300),

  confirmDeleteDoc(id, name) {
    Modal.confirm(`Delete "${name}"? All chunks and AI context from this document will be removed.`, () => {
      DB.Documents.delete(id);
      Toast.success('Document deleted');
      const item = document.getElementById(`doc-item-${id}`);
      if (item) item.remove();
    }, { title: 'Delete Document', confirmText: 'Delete', danger: true });
  },

  onUploadComplete(doc) {
    DocumentsPage.render();
  },

  initDragDrop() {
    const dropzone = document.querySelector('.file-dropzone');
    if (!dropzone) return;
    dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('drag-over'); });
    dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
    dropzone.addEventListener('drop', e => {
      e.preventDefault();
      dropzone.classList.remove('drag-over');
      const files = e.dataTransfer?.files;
      if (files?.length) {
        const input = dropzone.querySelector('input[type="file"]');
        if (input) {
          const dt = new DataTransfer();
          Array.from(files).forEach(f => dt.items.add(f));
          input.files = dt.files;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
    });
  },
};
