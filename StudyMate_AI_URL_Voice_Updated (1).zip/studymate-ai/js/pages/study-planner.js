/**
 * StudyMate AI — Study Planner Page
 */
window.StudyPlannerPage = {
  currentPlan: null,

  render() {
    const root = document.getElementById('app-root');
    const subjects = DB.Subjects.list();
    const savedPlans = DB.StudyPlans.list();

    root.innerHTML = AppShell.renderLayout('Study Planner', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">📅 Study Planner</h1>
          <p class="page-subtitle">Create AI-powered personalized study schedules for your exams</p>
        </div>
      </div>

      <div class="grid" style="grid-template-columns:360px 1fr;gap:24px;">
        <!-- Config Panel -->
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="card">
            <div class="card-header"><div class="card-title">Create Study Plan</div></div>
            <div style="display:flex;flex-direction:column;gap:14px;">
              <div class="form-group">
                <label class="form-label">Plan Title <span class="required">*</span></label>
                <input class="form-input" id="plan-title" type="text" placeholder="e.g. End Semester Exam Prep" />
              </div>
              <div class="form-group">
                <label class="form-label">Exam Date <span class="required">*</span></label>
                <input class="form-input" id="plan-date" type="date" min="${new Date().toISOString().split('T')[0]}" />
              </div>
              <div class="form-group">
                <label class="form-label">Study Hours per Day</label>
                <select class="form-select" id="plan-hours">
                  ${[2,3,4,5,6,8].map(h => `<option value="${h}" ${h===4?'selected':''}>${h} hours/day</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Subjects to Cover</label>
                <div style="display:flex;flex-direction:column;gap:6px;">
                  ${subjects.length === 0
                    ? `<div style="font-size:13px;color:var(--text-muted);">No subjects. <a href="#/subjects">Add subjects first.</a></div>`
                    : subjects.map(s => `
                        <div class="form-check">
                          <input type="checkbox" id="plan-sub-${s.id}" value="${s.id}" class="plan-sub-check" checked />
                          <label class="form-check-label" for="plan-sub-${s.id}" style="font-size:12px;">${s.name}</label>
                        </div>
                      `).join('')
                  }
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Preferences (optional)</label>
                <textarea class="form-textarea" id="plan-pref" rows="2" placeholder="e.g. Morning study preferred, weak in Unit 3, holiday on Sunday…"></textarea>
              </div>
              <button class="btn btn-primary" onclick="StudyPlannerPage.generatePlan()">
                🤖 Generate Study Plan
              </button>
            </div>
          </div>

          ${savedPlans.length > 0 ? `
            <div class="card">
              <div class="card-header"><div class="card-title">Saved Plans (${savedPlans.length})</div></div>
              <div style="display:flex;flex-direction:column;gap:8px;max-height:280px;overflow-y:auto;">
                ${savedPlans.map(p => `
                  <div style="padding:10px;border:1px solid var(--border-default);border-radius:10px;cursor:pointer;transition:var(--transition-fast);"
                       onclick="StudyPlannerPage.loadPlan('${p.id}')"
                       onmouseenter="this.style.borderColor='var(--brand-primary)'"
                       onmouseleave="this.style.borderColor='var(--border-default)'">
                    <div style="font-size:13px;font-weight:600;">${Helpers.truncate(p.title,32)}</div>
                    <div style="font-size:11px;color:var(--text-muted);">Exam: ${Helpers.formatDate(p.examDate)} · ${p.completedTasks}/${p.totalTasks} tasks done</div>
                    <div class="progress-bar progress-sm" style="margin-top:6px;">
                      <div class="progress-fill" style="width:${p.totalTasks ? Math.round(p.completedTasks/p.totalTasks*100) : 0}%;"></div>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          ` : ''}
        </div>

        <!-- Plan Output -->
        <div id="plan-output">
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:400px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;text-align:center;color:var(--text-muted);">
            <div style="font-size:64px;opacity:0.3;">📅</div>
            <div style="font-size:16px;font-weight:600;">Your study plan will appear here</div>
            <div style="font-size:13px;max-width:400px;">Set your exam date, study hours, and subjects. The AI will create a structured day-by-day study schedule.</div>
          </div>
        </div>
      </div>
    `);
  },

  async generatePlan() {
    const title = document.getElementById('plan-title')?.value?.trim();
    const examDate = document.getElementById('plan-date')?.value;
    if (!title) { Toast.error('Please enter a plan title'); return; }
    if (!examDate) { Toast.error('Please select an exam date'); return; }

    const selectedSubs = Array.from(document.querySelectorAll('.plan-sub-check:checked')).map(c => c.value);
    const subjects = selectedSubs.map(id => DB.Subjects.get(id)).filter(Boolean);
    const hoursPerDay = parseInt(document.getElementById('plan-hours')?.value || '4');
    const preferences = document.getElementById('plan-pref')?.value?.trim();

    if (!AIService.isConfigured()) { Toast.error('Please configure AI key in Settings'); return; }

    const daysLeft = Math.ceil((new Date(examDate) - new Date()) / (1000*60*60*24));
    if (daysLeft < 1) { Toast.error('Exam date must be in the future'); return; }

    const output = document.getElementById('plan-output');
    if (output) {
      output.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:center;min-height:300px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;">
          <div class="spinner spinner-xl"></div>
          <div>
            <div style="font-size:15px;font-weight:600;">Creating your ${daysLeft}-day study plan…</div>
            <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">AI is scheduling ${subjects.length} subjects across ${hoursPerDay}h/day</div>
          </div>
        </div>
      `;
    }

    try {
      const planData = await AIService.generateStudyPlan({
        subjects: subjects.map(s => s.name),
        examDate,
        hoursPerDay,
        remainingTopics: null,
        preferences,
      });

      const tasks = planData.tasks?.map(t => ({ ...t, id: StorageService.generateId('task_') })) || [];
      const plan = DB.StudyPlans.create({
        title,
        subjectIds: selectedSubs,
        examDate,
        hoursPerDay,
        tasks,
      });

      this.currentPlan = plan;
      this.renderPlan(plan);
      Toast.success('Study plan created!');
    } catch (err) {
      if (output) {
        output.innerHTML = `
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:300px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;">
            <div style="font-size:48px;">⚠️</div>
            <div style="font-size:15px;font-weight:600;color:var(--brand-danger);">Plan Generation Failed</div>
            <div style="font-size:13px;color:var(--text-muted);">${err.message}</div>
            <button class="btn btn-outline" onclick="StudyPlannerPage.generatePlan()">↻ Try Again</button>
          </div>
        `;
      }
      Toast.error('Plan generation failed: ' + err.message);
    }
  },

  loadPlan(id) {
    const plan = DB.StudyPlans.get(id);
    if (plan) { this.currentPlan = plan; this.renderPlan(plan); }
  },

  renderPlan(plan) {
    const output = document.getElementById('plan-output');
    if (!output) return;
    const pct = plan.totalTasks ? Math.round(plan.completedTasks / plan.totalTasks * 100) : 0;
    const daysLeft = Math.max(0, Math.ceil((new Date(plan.examDate) - new Date()) / (1000*60*60*24)));

    // Group tasks by date
    const byDate = {};
    (plan.tasks || []).forEach(t => {
      if (!byDate[t.date]) byDate[t.date] = [];
      byDate[t.date].push(t);
    });

    const typeIcon = { study:'📖', revision:'↻', quiz:'✏️', pyq_practice:'🔍', break:'☕', rest:'😴' };

    output.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:20px;">
        <!-- Plan Header -->
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:16px;">
            <div>
              <h3 style="font-size:18px;font-weight:700;">${plan.title}</h3>
              <div style="font-size:13px;color:var(--text-muted);">Exam: ${Helpers.formatDate(plan.examDate)} · ${daysLeft} days left · ${plan.hoursPerDay}h/day</div>
            </div>
            <div style="text-align:right;">
              <div style="font-size:28px;font-weight:800;color:var(--brand-primary);">${pct}%</div>
              <div style="font-size:12px;color:var(--text-muted);">Complete</div>
            </div>
          </div>
          <div class="progress-bar">
            <div class="progress-fill" style="width:${pct}%;"></div>
          </div>
          <div style="display:flex;gap:16px;margin-top:12px;font-size:12px;color:var(--text-muted);">
            <span>✓ ${plan.completedTasks} done</span>
            <span>○ ${plan.totalTasks - plan.completedTasks} remaining</span>
            <span>📅 ${Object.keys(byDate).length} study days</span>
          </div>
        </div>

        <!-- Task List -->
        <div style="display:flex;flex-direction:column;gap:16px;max-height:60vh;overflow-y:auto;">
          ${Object.entries(byDate).sort(([a],[b]) => new Date(a)-new Date(b)).map(([date, tasks]) => `
            <div>
              <div style="font-size:13px;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px;">
                ${Helpers.formatDate(date, {weekday:'long', day:'numeric', month:'short'})}
                ${date === new Date().toISOString().split('T')[0] ? '<span class="badge badge-primary" style="margin-left:8px;font-size:10px;">TODAY</span>' : ''}
              </div>
              <div style="display:flex;flex-direction:column;gap:8px;">
                ${tasks.map(task => `
                  <div class="plan-item ${task.completed ? 'completed' : ''}" id="plan-task-${task.id}">
                    <div class="plan-checkbox ${task.completed ? 'checked' : ''}"
                         onclick="StudyPlannerPage.toggleTask('${plan.id}','${task.id}')">
                      ${task.completed ? '✓' : ''}
                    </div>
                    <div style="flex:1;">
                      <div class="plan-title">${typeIcon[task.type] || '📌'} ${task.title}</div>
                      <div class="plan-subtitle">${task.subject || ''} ${task.duration ? '· ' + Helpers.formatDuration(task.duration) : ''} ${task.description ? '· ' + task.description : ''}</div>
                    </div>
                    <span class="badge badge-${task.priority === 'high' ? 'danger' : task.priority === 'medium' ? 'warning' : 'gray'}" style="font-size:10px;">${task.priority || 'normal'}</span>
                  </div>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  toggleTask(planId, taskId) {
    const plan = DB.StudyPlans.get(planId);
    if (!plan) return;
    const task = plan.tasks.find(t => t.id === taskId);
    if (!task) return;
    DB.StudyPlans.updateTask(planId, taskId, { completed: !task.completed });
    this.currentPlan = DB.StudyPlans.get(planId);
    this.renderPlan(this.currentPlan);
  },
};

/** Stub files */
window.ExamModePageStub = true;
window.ProgressPageStub = true;
