/** StudyMate AI — Forgot Password page (stub, included in register.js) */
window.ForgotPasswordStub = true; // already defined in register.js
