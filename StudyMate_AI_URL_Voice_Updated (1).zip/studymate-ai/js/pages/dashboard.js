/**
 * StudyMate AI — Dashboard Page
 */
window.DashboardPage = {
  render() {
    const root = document.getElementById('app-root');
    if (!root) return;

    const user = AuthService.getCurrentUser();
    const profile = AuthService.getProfile();
    const stats = DB.Progress.getStats();
    const subjects = DB.Subjects.list();
    const recentDocs = DB.Documents.list().slice(0, 4);
    const recentConvs = DB.Conversations.list().slice(0, 3);
    const recentNotes = DB.Notes.list().slice(0, 3);
    const weakTopics = DB.Progress.getWeakTopics();
    const usage = UsageService.getAllUsage();
    const plan = DB.Subscriptions.getCurrentPlan();

    const name = profile?.name || user?.name || 'Student';
    const greeting = this.getGreeting();
    const hour = new Date().getHours();

    root.innerHTML = AppShell.renderLayout('Dashboard', `
      <!-- Welcome Banner -->
      <div class="dashboard-welcome">
        <div style="position:relative;z-index:1;">
          <div class="dashboard-welcome-title">${greeting}, ${name.split(' ')[0]}! 👋</div>
          <div class="dashboard-welcome-subtitle">
            ${profile?.course ? `${profile.course}` : 'Student'} 
            ${profile?.semester ? `· ${profile.semester}` : ''}
            ${profile?.university ? `· ${profile.university}` : ''}
          </div>
          <div class="dashboard-quick-actions">
            <a href="#/ai-chat" class="quick-action-btn">💬 Ask AI</a>
            <a href="#/documents" class="quick-action-btn">⬆️ Upload PDF</a>
            <a href="#/notes" class="quick-action-btn">📝 Generate Notes</a>
            <a href="#/quiz" class="quick-action-btn">✏️ Create Quiz</a>
            <a href="#/pyq-analyzer" class="quick-action-btn">🔍 Analyze PYQ</a>
            <a href="#/study-planner" class="quick-action-btn">📅 Study Plan</a>
          </div>
        </div>
      </div>

      <!-- Stats Grid -->
      <div class="grid grid-4 stagger" style="margin-bottom:var(--space-8);">
        <div class="stat-card">
          <div class="stat-card-icon stat-card-icon-primary">📄</div>
          <div>
            <div class="stat-card-value">${stats.totalDocuments}</div>
            <div class="stat-card-label">Documents Uploaded</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-card-icon stat-card-icon-success">✏️</div>
          <div>
            <div class="stat-card-value">${stats.totalQuizAttempts}</div>
            <div class="stat-card-label">Quizzes Attempted</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-card-icon stat-card-icon-warning">📊</div>
          <div>
            <div class="stat-card-value">${stats.averageQuizScore || 0}%</div>
            <div class="stat-card-label">Average Quiz Score</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-card-icon stat-card-icon-cyan">💬</div>
          <div>
            <div class="stat-card-value">${stats.totalChatSessions}</div>
            <div class="stat-card-label">AI Chat Sessions</div>
          </div>
        </div>
      </div>

      <div class="grid" style="grid-template-columns:2fr 1fr;gap:24px;margin-bottom:var(--space-6);">
        <!-- Subjects -->
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">My Subjects</div>
              <div class="card-subtitle">${subjects.length} subject${subjects.length !== 1 ? 's' : ''} this semester</div>
            </div>
            <a href="#/subjects" class="btn btn-sm btn-outline">View All</a>
          </div>
          ${subjects.length === 0
            ? `<div class="empty-state" style="padding:32px 16px;">
                <div class="empty-state-icon">📚</div>
                <div class="empty-state-title">No subjects yet</div>
                <div class="empty-state-desc">Add your first subject to organize your study material.</div>
                <a href="#/subjects" class="btn btn-primary btn-sm" style="margin-top:12px;">+ Add Subject</a>
               </div>`
            : `<div style="display:flex;flex-direction:column;gap:10px;">
                ${subjects.slice(0, 5).map(sub => `
                  <a href="#/subjects?id=${sub.id}" style="text-decoration:none;" class="transition-fast">
                    <div style="display:flex;align-items:center;gap:12px;padding:12px;border-radius:10px;border:1px solid var(--border-default);transition:var(--transition-fast);"
                         onmouseenter="this.style.borderColor='var(--brand-primary)'"
                         onmouseleave="this.style.borderColor='var(--border-default)'">
                      <div style="width:36px;height:36px;border-radius:10px;background:${sub.color}20;display:flex;align-items:center;justify-content:center;">
                        <div style="width:10px;height:10px;border-radius:50%;background:${sub.color};"></div>
                      </div>
                      <div style="flex:1;min-width:0;">
                        <div style="font-size:14px;font-weight:600;color:var(--text-primary);">${Helpers.truncate(sub.name, 35)}</div>
                        <div style="font-size:12px;color:var(--text-muted);">${sub.code ? sub.code + ' · ' : ''}${sub.semester || ''} · ${sub.documentCount || 0} doc${sub.documentCount !== 1 ? 's' : ''}</div>
                      </div>
                    </div>
                  </a>
                `).join('')}
              </div>`
          }
        </div>

        <!-- Sidebar cards -->
        <div style="display:flex;flex-direction:column;gap:16px;">
          <!-- Usage -->
          <div class="card">
            <div class="card-header" style="margin-bottom:12px;padding-bottom:12px;">
              <div class="card-title">Monthly Usage</div>
              <span class="badge ${plan === 'premium' ? 'badge-warning' : 'badge-gray'}">${plan === 'premium' ? '💎 Premium' : 'Free'}</span>
            </div>
            <div style="display:flex;flex-direction:column;gap:12px;">
              ${Object.entries(usage).slice(0, 4).map(([metric, data]) => {
                const labels = {
                  pdf_uploads_per_month: 'PDF Uploads',
                  ai_questions_per_month: 'AI Questions',
                  notes_generations_per_month: 'Notes',
                  quiz_generations_per_month: 'Quizzes',
                };
                const label = labels[metric];
                if (!label) return '';
                const pct = Math.min(100, data.percentage || 0);
                const color = pct >= 90 ? 'var(--brand-danger)' : pct >= 70 ? 'var(--brand-accent)' : 'var(--brand-primary)';
                return `
                  <div class="usage-bar">
                    <div class="usage-bar-header">
                      <span class="usage-bar-label">${label}</span>
                      <span>${data.current}/${data.limit}</span>
                    </div>
                    <div class="progress-bar progress-sm">
                      <div class="progress-fill" style="width:${pct}%;background:${color};"></div>
                    </div>
                  </div>
                `;
              }).join('')}
            </div>
            ${plan === 'free' ? `
              <a href="#/pricing" class="btn btn-sm btn-outline" style="width:100%;margin-top:16px;justify-content:center;">
                💎 Upgrade to Premium
              </a>
            ` : ''}
          </div>

          <!-- AI Setup Status -->
          ${!AIService.isConfigured() ? `
            <div class="card" style="border-color:rgba(245,158,11,0.4);background:linear-gradient(135deg,rgba(245,158,11,0.05),rgba(239,68,68,0.02));">
              <div style="display:flex;gap:10px;align-items:flex-start;">
                <span style="font-size:20px;">⚙️</span>
                <div>
                  <div style="font-size:14px;font-weight:600;margin-bottom:4px;">Configure AI</div>
                  <div style="font-size:12px;color:var(--text-muted);margin-bottom:10px;">Add your Gemini API key to enable AI features.</div>
                  <a href="#/profile?tab=settings" class="btn btn-sm btn-primary">Set Up AI →</a>
                </div>
              </div>
            </div>
          ` : `
            <div class="card" style="border-color:rgba(16,185,129,0.3);background:#F0FDF4;">
              <div style="display:flex;gap:10px;align-items:center;">
                <span style="font-size:20px;">🤖</span>
                <div>
                  <div style="font-size:14px;font-weight:600;color:var(--brand-success);">AI Ready</div>
                  <div style="font-size:12px;color:var(--text-muted);">Gemini AI is configured and active.</div>
                </div>
              </div>
            </div>
          `}
        </div>
      </div>

      <div class="grid grid-3" style="gap:24px;margin-bottom:var(--space-6);">
        <!-- Recent Documents -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">Recent Documents</div>
            <a href="#/documents" class="btn btn-sm btn-ghost">View All →</a>
          </div>
          ${recentDocs.length === 0
            ? `<div style="text-align:center;padding:24px;color:var(--text-muted);font-size:13px;">No documents yet.<br/><a href="#/documents" class="btn btn-sm btn-primary" style="margin-top:10px;">Upload Now</a></div>`
            : recentDocs.map(doc => `
                <div class="doc-item" style="margin-bottom:8px;">
                  <div class="doc-icon ${doc.fileType?.includes('pdf') || doc.name?.endsWith('.pdf') ? 'doc-icon-pdf' : 'doc-icon-txt'}">
                    ${doc.name?.endsWith('.pdf') ? '📑' : '📃'}
                  </div>
                  <div class="doc-info">
                    <div class="doc-name">${Helpers.truncate(doc.name, 28)}</div>
                    <div class="doc-meta">
                      <span class="badge badge-${doc.status === 'ready' ? 'success' : doc.status === 'failed' ? 'danger' : 'warning'}" style="font-size:10px;">${doc.status}</span>
                      · ${Helpers.timeAgo(doc.createdAt)}
                    </div>
                  </div>
                </div>
              `).join('')
          }
        </div>

        <!-- Recent AI Chats -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">Recent AI Chats</div>
            <a href="#/ai-chat" class="btn btn-sm btn-ghost">View All →</a>
          </div>
          ${recentConvs.length === 0
            ? `<div style="text-align:center;padding:24px;color:var(--text-muted);font-size:13px;">No chats yet.<br/><a href="#/ai-chat" class="btn btn-sm btn-primary" style="margin-top:10px;">Start Chat</a></div>`
            : recentConvs.map(c => `
                <a href="#/ai-chat?id=${c.id}" style="display:block;padding:10px;border-radius:10px;border:1px solid var(--border-default);margin-bottom:8px;text-decoration:none;transition:var(--transition-fast);"
                   onmouseenter="this.style.borderColor='var(--brand-primary)'"
                   onmouseleave="this.style.borderColor='var(--border-default)'">
                  <div style="font-size:13px;font-weight:500;color:var(--text-primary);">${Helpers.truncate(c.title, 36)}</div>
                  <div style="font-size:11px;color:var(--text-muted);margin-top:3px;">${c.messageCount} messages · ${Helpers.timeAgo(c.updatedAt)}</div>
                </a>
              `).join('')
          }
        </div>

        <!-- Weak Topics & Progress -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">Focus Areas</div>
            <a href="#/progress" class="btn btn-sm btn-ghost">Details →</a>
          </div>
          ${weakTopics.length === 0
            ? `<div style="text-align:center;padding:24px;color:var(--text-muted);font-size:13px;">Take a quiz to identify weak topics.<br/><a href="#/quiz" class="btn btn-sm btn-primary" style="margin-top:10px;">Take Quiz</a></div>`
            : `<div style="display:flex;flex-direction:column;gap:8px;">
                <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">Topics needing more practice:</div>
                ${weakTopics.map(w => `
                  <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:var(--bg-raised);border-radius:8px;">
                    <span style="font-size:13px;color:var(--text-primary);">⚡ ${w.topic}</span>
                    <span class="badge badge-danger">${w.count} error${w.count !== 1 ? 's' : ''}</span>
                  </div>
                `).join('')}
               </div>`
          }
        </div>
      </div>

      <!-- Feature Cards -->
      <div class="grid grid-3 stagger" style="gap:20px;">
        ${[
          { href:'/ai-chat', icon:'💬', title:'AI Study Chat', desc:'Ask questions from your uploaded material', btn:'Start Chat' },
          { href:'/pyq-analyzer', icon:'🔍', title:'PYQ Analyzer', desc:'Identify repeated topics from past papers', btn:'Analyze PYQs' },
          { href:'/exam-mode', icon:'⏱️', title:'Exam Mode', desc:'Practice timed tests under exam conditions', btn:'Start Exam' },
        ].map(f => `
          <div class="feature-card" style="cursor:pointer;" onclick="Router.navigate('${f.href}')">
            <div class="feature-icon">${f.icon}</div>
            <h3 style="font-size:16px;font-weight:700;margin-bottom:6px;">${f.title}</h3>
            <p style="font-size:13px;color:var(--text-secondary);margin-bottom:16px;">${f.desc}</p>
            <a href="#${f.href}" class="btn btn-sm btn-outline">${f.btn} →</a>
          </div>
        `).join('')}
      </div>
    `);
  },

  getGreeting() {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  },
};
