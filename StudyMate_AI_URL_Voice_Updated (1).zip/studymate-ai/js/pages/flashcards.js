/**
 * StudyMate AI — Flashcards Page
 */
window.FlashcardsPage = {
  currentDeckId: null,
  currentCardIndex: 0,
  isFlipped: false,

  render() {
    const root = document.getElementById('app-root');
    const subjects = DB.Subjects.list();
    const docs = DB.Documents.list().filter(d => d.status === 'ready');
    const decks = DB.Flashcards.listDecks();

    root.innerHTML = AppShell.renderLayout('Flashcards', `
      <div class="page-header">
        <div class="page-title-group">
          <h1 class="page-title">🃏 Flashcards</h1>
          <p class="page-subtitle">Generate and review flashcards from your study material</p>
        </div>
      </div>

      <div class="grid" style="grid-template-columns:320px 1fr;gap:24px;">
        <!-- Config -->
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="card">
            <div class="card-header"><div class="card-title">Generate Flashcards</div></div>
            <div style="display:flex;flex-direction:column;gap:14px;">
              <div class="form-group">
                <label class="form-label">Deck Title <span class="required">*</span></label>
                <input class="form-input" id="deck-title" type="text" placeholder="e.g. DBMS Definitions" />
              </div>
              <div class="form-group">
                <label class="form-label">Source Document</label>
                <select class="form-select" id="deck-doc">
                  <option value="">All documents</option>
                  ${docs.map(d => `<option value="${d.id}">${Helpers.truncate(d.name,38)}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Topic</label>
                <input class="form-input" id="deck-topic" type="text" placeholder="e.g. Normalization" />
              </div>
              <div class="form-group">
                <label class="form-label">Number of Cards</label>
                <select class="form-select" id="deck-count">
                  <option value="10">10 cards</option>
                  <option value="15" selected>15 cards</option>
                  <option value="20">20 cards</option>
                  <option value="30">30 cards</option>
                </select>
              </div>
              <button class="btn btn-primary" onclick="FlashcardsPage.generate()">🤖 Generate Flashcards</button>
            </div>
          </div>

          <!-- Saved Decks -->
          <div class="card">
            <div class="card-header"><div class="card-title">My Decks (${decks.length})</div></div>
            ${decks.length === 0
              ? `<div style="font-size:13px;color:var(--text-muted);text-align:center;padding:16px;">No flashcard decks yet</div>`
              : `<div style="display:flex;flex-direction:column;gap:8px;max-height:350px;overflow-y:auto;">
                  ${decks.map(d => `
                    <div style="padding:10px;border:1px solid var(--border-default);border-radius:10px;cursor:pointer;transition:var(--transition-fast);"
                         onclick="FlashcardsPage.loadDeck('${d.id}')"
                         onmouseenter="this.style.borderColor='var(--brand-primary)'"
                         onmouseleave="this.style.borderColor='var(--border-default)'">
                      <div style="font-size:13px;font-weight:600;">${Helpers.truncate(d.title,30)}</div>
                      <div style="font-size:11px;color:var(--text-muted);">${d.cardCount} cards · ${d.learnedCount} learned</div>
                      <div class="progress-bar progress-sm" style="margin-top:6px;">
                        <div class="progress-fill progress-fill-success" style="width:${d.cardCount ? Math.round(d.learnedCount/d.cardCount*100) : 0}%;"></div>
                      </div>
                    </div>
                  `).join('')}
                </div>`
            }
          </div>
        </div>

        <!-- Flashcard Viewer -->
        <div id="flashcard-area">
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:400px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;text-align:center;color:var(--text-muted);">
            <div style="font-size:64px;opacity:0.3;">🃏</div>
            <div style="font-size:16px;font-weight:600;">Select or generate a flashcard deck</div>
            <div style="font-size:13px;max-width:300px;">Generate flashcards from your study material or select an existing deck to start reviewing.</div>
          </div>
        </div>
      </div>
    `);
  },

  async generate() {
    const title = document.getElementById('deck-title')?.value?.trim();
    const topic = document.getElementById('deck-topic')?.value?.trim() || title;
    const docId = document.getElementById('deck-doc')?.value;
    const count = parseInt(document.getElementById('deck-count')?.value || '15');

    if (!title) { Toast.error('Please enter a deck title'); return; }
    if (!AIService.isConfigured()) { Toast.error('Please configure AI key in Settings'); return; }

    const chunks = RAGEngine.retrieve({ query: topic, documentIds: docId ? [docId] : null, topK: 8 });
    const content = chunks.length > 0
      ? chunks.map(c => c.text).join('\n\n')
      : (docId ? DB.Documents.get(docId)?.content || '' : topic);

    const area = document.getElementById('flashcard-area');
    if (area) {
      area.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;min-height:300px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;"><div class="spinner spinner-xl"></div><div><div style="font-size:15px;font-weight:600;">Generating ${count} flashcards…</div></div></div>`;
    }

    try {
      const cards = await AIService.generateFlashcards({ topic, content, count });
      const deck = DB.Flashcards.createDeck({ title, subjectId: null, cards });
      Toast.success(`${cards.length} flashcards created!`);
      this.loadDeck(deck.id);
      this.render(); // Refresh sidebar
      setTimeout(() => this.loadDeck(deck.id), 100);
    } catch (err) {
      if (area) {
        area.innerHTML = `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:300px;gap:16px;background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-xl);padding:40px;"><div style="font-size:48px;">⚠️</div><div style="font-size:15px;color:var(--brand-danger);">${err.message}</div><button class="btn btn-outline" onclick="FlashcardsPage.generate()">↻ Retry</button></div>`;
      }
      Toast.error('Flashcard generation failed: ' + err.message);
    }
  },

  loadDeck(id) {
    this.currentDeckId = id;
    this.currentCardIndex = 0;
    this.isFlipped = false;
    this.renderDeck();
  },

  renderDeck() {
    const area = document.getElementById('flashcard-area');
    if (!area) return;
    const deck = DB.Flashcards.getDeck(this.currentDeckId);
    if (!deck || deck.cards.length === 0) {
      area.innerHTML = `<div class="empty-state"><div class="empty-state-icon">🃏</div><div class="empty-state-title">Empty deck</div></div>`;
      return;
    }

    const card = deck.cards[this.currentCardIndex];
    const pct = Math.round((this.currentCardIndex + 1) / deck.cards.length * 100);
    const learnedPct = Math.round(deck.learnedCount / deck.cards.length * 100);

    area.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:20px;">
        <!-- Deck Header -->
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <h3 style="font-size:18px;font-weight:700;">${deck.title}</h3>
            <div style="font-size:13px;color:var(--text-muted);">${deck.cardCount} cards · ${deck.learnedCount} learned (${learnedPct}%)</div>
          </div>
          <div style="display:flex;gap:8px;">
            <button class="btn btn-sm btn-ghost" onclick="FlashcardsPage.shuffleDeck()">🔀 Shuffle</button>
            <button class="btn btn-sm btn-ghost" style="color:var(--brand-danger);" onclick="FlashcardsPage.deleteDeck('${deck.id}')">🗑</button>
          </div>
        </div>

        <!-- Progress -->
        <div>
          <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--text-muted);margin-bottom:4px;">
            <span>Card ${this.currentCardIndex + 1} of ${deck.cards.length}</span>
            <span>${learnedPct}% learned</span>
          </div>
          <div class="progress-bar">
            <div class="progress-fill progress-fill-success" style="width:${learnedPct}%;"></div>
          </div>
        </div>

        <!-- Flashcard -->
        <div class="flashcard-scene" onclick="FlashcardsPage.flip()">
          <div class="flashcard ${this.isFlipped ? 'flipped' : ''}" id="active-flashcard">
            <div class="flashcard-face flashcard-front">
              <div class="flashcard-label">Question / Term</div>
              <div class="flashcard-content">${card.front}</div>
              <div style="margin-top:20px;font-size:12px;opacity:0.6;">Click to reveal answer</div>
            </div>
            <div class="flashcard-face flashcard-back">
              <div class="flashcard-label">Answer / Definition</div>
              <div class="flashcard-content" style="font-size:16px;">${card.back}</div>
            </div>
          </div>
        </div>

        <!-- Actions -->
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
          <div style="display:flex;gap:8px;">
            <button class="btn btn-outline ${card.difficulty === 'hard' ? 'btn-danger' : ''}" 
                    onclick="FlashcardsPage.markDifficult()">
              ⚡ Difficult
            </button>
            <button class="btn btn-outline ${card.learned ? 'btn-success' : ''}"
                    onclick="FlashcardsPage.markLearned()">
              ✓ ${card.learned ? 'Learned' : 'Mark Learned'}
            </button>
          </div>
          <div style="display:flex;gap:8px;">
            <button class="btn btn-ghost" onclick="FlashcardsPage.prevCard()" ${this.currentCardIndex === 0 ? 'disabled' : ''}>← Prev</button>
            <button class="btn btn-primary" onclick="FlashcardsPage.nextCard()" ${this.currentCardIndex >= deck.cards.length - 1 ? 'disabled' : ''}>Next →</button>
          </div>
        </div>

        <!-- Card Grid -->
        <div style="display:flex;flex-wrap:wrap;gap:4px;">
          ${deck.cards.map((c, i) => `
            <button style="width:28px;height:28px;border-radius:6px;border:1.5px solid ${i === this.currentCardIndex ? 'var(--brand-primary)' : 'var(--border-default)'};background:${c.learned ? 'var(--brand-success)' : i === this.currentCardIndex ? 'var(--brand-primary-light)' : 'var(--bg-surface)'};cursor:pointer;font-size:11px;font-weight:700;color:${c.learned ? 'white' : i === this.currentCardIndex ? 'var(--brand-primary)' : 'var(--text-muted)'};"
                    onclick="FlashcardsPage.goToCard(${i})">${i+1}</button>
          `).join('')}
        </div>

        <div class="ai-disclaimer">
          <span class="ai-disclaimer-icon">⚠</span>
          AI-generated flashcards — verify important definitions with your textbook
        </div>
      </div>
    `;
  },

  flip() {
    this.isFlipped = !this.isFlipped;
    const card = document.getElementById('active-flashcard');
    if (card) card.classList.toggle('flipped', this.isFlipped);
  },

  nextCard() {
    const deck = DB.Flashcards.getDeck(this.currentDeckId);
    if (!deck || this.currentCardIndex >= deck.cards.length - 1) return;
    this.currentCardIndex++;
    this.isFlipped = false;
    this.renderDeck();
  },

  prevCard() {
    if (this.currentCardIndex <= 0) return;
    this.currentCardIndex--;
    this.isFlipped = false;
    this.renderDeck();
  },

  goToCard(index) {
    this.currentCardIndex = index;
    this.isFlipped = false;
    this.renderDeck();
  },

  markLearned() {
    const deck = DB.Flashcards.getDeck(this.currentDeckId);
    if (!deck) return;
    const card = deck.cards[this.currentCardIndex];
    DB.Flashcards.updateCard(this.currentDeckId, card.id, { learned: !card.learned });
    this.renderDeck();
  },

  markDifficult() {
    const deck = DB.Flashcards.getDeck(this.currentDeckId);
    if (!deck) return;
    const card = deck.cards[this.currentCardIndex];
    DB.Flashcards.updateCard(this.currentDeckId, card.id, { difficulty: card.difficulty === 'hard' ? 'normal' : 'hard' });
    this.renderDeck();
  },

  shuffleDeck() {
    const deck = DB.Flashcards.getDeck(this.currentDeckId);
    if (!deck) return;
    const shuffled = [...deck.cards].sort(() => Math.random() - 0.5);
    StorageService.updateItem('flashcard_decks', this.currentDeckId, { cards: shuffled });
    this.currentCardIndex = 0;
    this.isFlipped = false;
    this.renderDeck();
    Toast.info('Deck shuffled');
  },

  deleteDeck(id) {
    Modal.confirm('Delete this flashcard deck?', () => {
      DB.Flashcards.deleteDeck(id);
      Toast.success('Deck deleted');
      this.render();
    }, { title: 'Delete Deck', confirmText: 'Delete', danger: true });
  },
};
