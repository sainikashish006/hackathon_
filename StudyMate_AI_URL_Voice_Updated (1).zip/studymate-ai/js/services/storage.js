/**
 * StudyMate AI — Storage Service
 * Abstraction layer over localStorage.
 * In production, this maps to Supabase/PostgreSQL via API.
 *
 * Data Model (database-ready schemas):
 * - users, profiles, courses, semesters, subjects
 * - documents, document_chunks
 * - conversations, messages
 * - generated_notes, quizzes, questions, quiz_attempts
 * - pyq_analyses, study_plans, study_sessions
 * - flashcard_decks, flashcards
 * - subscriptions, usage_records
 */

window.StorageService = (() => {
  const PREFIX = 'sm_';

  function getKey(namespace) { return PREFIX + namespace; }

  function get(namespace, defaultValue = null) {
    try {
      const raw = localStorage.getItem(getKey(namespace));
      return raw ? JSON.parse(raw) : defaultValue;
    } catch { return defaultValue; }
  }

  function set(namespace, value) {
    try {
      localStorage.setItem(getKey(namespace), JSON.stringify(value));
      return true;
    } catch (e) {
      console.error('Storage write error:', e);
      return false;
    }
  }

  function remove(namespace) {
    localStorage.removeItem(getKey(namespace));
  }

  function clear(prefix = null) {
    if (prefix) {
      Object.keys(localStorage)
        .filter(k => k.startsWith(PREFIX + prefix))
        .forEach(k => localStorage.removeItem(k));
    } else {
      Object.keys(localStorage)
        .filter(k => k.startsWith(PREFIX))
        .forEach(k => localStorage.removeItem(k));
    }
  }

  // ---- Generic collection helpers ----
  function getCollection(name) {
    return get(name, []);
  }
  function setCollection(name, items) {
    return set(name, items);
  }
  function insertItem(name, item) {
    const items = getCollection(name);
    items.unshift(item); // newest first
    return setCollection(name, items);
  }
  function updateItem(name, id, updates) {
    const items = getCollection(name);
    const idx = items.findIndex(i => i.id === id);
    if (idx === -1) return false;
    items[idx] = { ...items[idx], ...updates, updatedAt: new Date().toISOString() };
    return setCollection(name, items);
  }
  function deleteItem(name, id) {
    const items = getCollection(name).filter(i => i.id !== id);
    return setCollection(name, items);
  }
  function getItem(name, id) {
    return getCollection(name).find(i => i.id === id) || null;
  }
  function queryItems(name, predicate) {
    return getCollection(name).filter(predicate);
  }

  // ---- User-scoped helpers ----
  function getUserCollection(userId, name) {
    return queryItems(name, i => i.userId === userId);
  }

  // ---- ID generator ----
  function generateId(prefix = '') {
    return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  return {
    get, set, remove, clear,
    getCollection, setCollection,
    insertItem, updateItem, deleteItem, getItem, queryItems,
    getUserCollection,
    generateId,
  };
})();
