/**
 * StudyMate AI — Authentication Service
 * Handles register, login, logout, session management.
 * In production: integrates with Supabase Auth / Firebase Auth.
 * Passwords are hashed (SHA-256 via SubtleCrypto) — never stored plain.
 * Session token is stored in sessionStorage (not localStorage) for security.
 */

window.AuthService = (() => {
  const USERS_KEY = 'users';
  const SESSION_KEY = 'sm_session';
  const PROFILE_KEY = 'profiles';

  // ---- Password hashing (SHA-256) ----
  async function hashPassword(password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password + 'sm_salt_2024'); // pepper
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  // ---- Validation ----
  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
  function validatePassword(password) {
    if (password.length < 8) return 'Password must be at least 8 characters';
    if (!/[A-Z]/.test(password) && !/[0-9]/.test(password)) return 'Password must contain a letter and a number';
    return null;
  }
  function validateName(name) {
    if (!name || name.trim().length < 2) return 'Name must be at least 2 characters';
    return null;
  }

  // ---- Register ----
  async function register({ name, email, password, course }) {
    // Validate
    const nameErr = validateName(name);
    if (nameErr) return { success: false, error: nameErr };
    if (!validateEmail(email)) return { success: false, error: 'Invalid email address' };
    const passErr = validatePassword(password);
    if (passErr) return { success: false, error: passErr };

    // Check duplicate
    const users = StorageService.getCollection(USERS_KEY);
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { success: false, error: 'An account with this email already exists' };
    }

    const passwordHash = await hashPassword(password);
    const userId = StorageService.generateId('u_');
    const now = new Date().toISOString();

    const user = {
      id: userId,
      email: email.toLowerCase().trim(),
      passwordHash,
      name: name.trim(),
      emailVerified: true, // skipping email verification in demo
      createdAt: now,
      updatedAt: now,
    };

    // Profile
    const profile = {
      id: StorageService.generateId('p_'),
      userId,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      university: '',
      course: course || '',
      branch: '',
      semester: '',
      subjects: [],
      avatarInitials: name.trim().split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2),
      createdAt: now,
      updatedAt: now,
    };

    // Subscription
    const subscription = {
      id: StorageService.generateId('sub_'),
      userId,
      plan: 'free',
      status: 'active',
      startDate: now,
      renewalDate: null,
      paymentProviderCustomerId: null,
      subscriptionId: null,
      createdAt: now,
      updatedAt: now,
    };

    StorageService.insertItem(USERS_KEY, user);
    StorageService.insertItem(PROFILE_KEY, profile);
    StorageService.insertItem('subscriptions', subscription);

    // Create session
    const session = createSession(user);
    return { success: true, user: sanitizeUser(user), session, profile };
  }

  // ---- Login ----
  async function login({ email, password }) {
    if (!validateEmail(email)) return { success: false, error: 'Invalid email address' };
    if (!password) return { success: false, error: 'Password is required' };

    const users = StorageService.getCollection(USERS_KEY);
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase().trim());

    if (!user) return { success: false, error: 'No account found with this email' };

    const passwordHash = await hashPassword(password);
    if (passwordHash !== user.passwordHash) {
      return { success: false, error: 'Incorrect password' };
    }

    const session = createSession(user);
    return { success: true, user: sanitizeUser(user), session };
  }

  // ---- Session management ----
  function createSession(user) {
    const session = {
      userId: user.id,
      email: user.email,
      name: user.name,
      token: StorageService.generateId('tok_'),
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
    };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
    // Also persist to localStorage for page refreshes
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    return session;
  }

  function getSession() {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const session = JSON.parse(raw);
      if (new Date(session.expiresAt) < new Date()) {
        logout();
        return null;
      }
      return session;
    } catch { return null; }
  }

  function isAuthenticated() {
    return getSession() !== null;
  }

  function getCurrentUser() {
    const session = getSession();
    if (!session) return null;
    const users = StorageService.getCollection(USERS_KEY);
    const user = users.find(u => u.id === session.userId);
    return user ? sanitizeUser(user) : null;
  }

  function getCurrentUserId() {
    const session = getSession();
    return session ? session.userId : null;
  }

  function sanitizeUser(user) {
    const { passwordHash, ...safe } = user;
    return safe;
  }

  function logout() {
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
  }

  // ---- Password Reset (demo: generates reset token) ----
  function requestPasswordReset(email) {
    const users = StorageService.getCollection(USERS_KEY);
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) return { success: false, error: 'No account found with this email' };

    const token = StorageService.generateId('rst_');
    const resets = StorageService.getCollection('password_resets');
    resets.push({
      userId: user.id,
      token,
      expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
      used: false,
    });
    StorageService.setCollection('password_resets', resets);

    // In production: send email with reset link
    // Here: return token for demo purposes
    return { success: true, token, message: 'Password reset link sent (check console in demo mode)' };
  }

  async function resetPassword(token, newPassword) {
    const passErr = validatePassword(newPassword);
    if (passErr) return { success: false, error: passErr };

    const resets = StorageService.getCollection('password_resets');
    const reset = resets.find(r => r.token === token && !r.used);
    if (!reset) return { success: false, error: 'Invalid or expired reset token' };
    if (new Date(reset.expiresAt) < new Date()) return { success: false, error: 'Reset token expired' };

    const newHash = await hashPassword(newPassword);
    StorageService.updateItem(USERS_KEY, reset.userId, { passwordHash: newHash });

    // Mark token used
    reset.used = true;
    StorageService.setCollection('password_resets', resets);

    return { success: true };
  }

  // ---- Profile ----
  function getProfile(userId) {
    const id = userId || getCurrentUserId();
    if (!id) return null;
    return StorageService.queryItems(PROFILE_KEY, p => p.userId === id)[0] || null;
  }

  function updateProfile(updates) {
    const userId = getCurrentUserId();
    if (!userId) return { success: false, error: 'Not authenticated' };
    const profile = getProfile(userId);
    if (!profile) return { success: false, error: 'Profile not found' };
    StorageService.updateItem(PROFILE_KEY, profile.id, updates);
    return { success: true, profile: { ...profile, ...updates } };
  }

  return {
    register,
    login,
    logout,
    isAuthenticated,
    getCurrentUser,
    getCurrentUserId,
    getSession,
    requestPasswordReset,
    resetPassword,
    getProfile,
    updateProfile,
    validateEmail,
    validatePassword,
    validateName,
  };
})();
