/**
 * StudyMate AI — RAG Engine
 * Retrieval-Augmented Generation.
 * Retrieves the most relevant document chunks for a user query.
 *
 * In production: uses pgvector / Pinecone with real embedding similarity.
 * In this demo: uses keyword overlap scoring (TF-IDF-like similarity).
 */

window.RAGEngine = (() => {
  const TOP_K = AppConfig.RAG.TOP_K;
  const MIN_SIMILARITY = AppConfig.RAG.MIN_SIMILARITY;

  // ---- Similarity scoring ----
  function computeSimilarity(queryKeywords, chunkKeywords) {
    if (!chunkKeywords || chunkKeywords.length === 0) return 0;
    const querySet = new Set(queryKeywords);
    const matches = chunkKeywords.filter(k => querySet.has(k)).length;
    const total = Math.max(querySet.size, chunkKeywords.length);
    return total === 0 ? 0 : matches / total;
  }

  // ---- Retrieve relevant chunks ----
  function retrieve({ query, documentIds = [], subjectId = null, topK = TOP_K }) {
    const userId = AuthService.getCurrentUserId();
    if (!userId) return [];

    // Get all chunks for target documents
    let chunks;
    if (documentIds && documentIds.length > 0) {
      chunks = documentIds.flatMap(docId => DB.Documents.getChunks(docId));
    } else if (subjectId) {
      // Get all docs in subject, then all their chunks
      const docs = DB.Documents.list(subjectId).filter(d => d.status === 'ready');
      chunks = docs.flatMap(d => DB.Documents.getChunks(d.id));
    } else {
      // All user's documents
      const docs = DB.Documents.list().filter(d => d.status === 'ready');
      chunks = docs.flatMap(d => DB.Documents.getChunks(d.id));
    }

    if (chunks.length === 0) return [];

    // Extract query keywords
    const queryKeywords = DocumentProcessor.extractKeywords(query);

    // Also include exact phrase matching
    const queryWords = query.toLowerCase().split(/\s+/).filter(w => w.length > 3);

    // Score each chunk
    const scored = chunks.map(chunk => {
      let score = computeSimilarity(queryKeywords, chunk.keywords || []);

      // Boost for exact word matches in chunk text
      const chunkLower = (chunk.text || '').toLowerCase();
      const exactMatches = queryWords.filter(w => chunkLower.includes(w)).length;
      score += (exactMatches / Math.max(queryWords.length, 1)) * 0.5;

      // Get document info for display
      const doc = DB.Documents.get(chunk.documentId);
      return {
        ...chunk,
        score,
        documentName: doc ? doc.name : 'Unknown Document',
        subjectId: doc ? doc.subjectId : null,
      };
    });

    // Sort by score, take top K, filter by minimum similarity
    const results = scored
      .sort((a, b) => b.score - a.score)
      .slice(0, topK * 2) // get extra to filter
      .filter(c => c.score >= MIN_SIMILARITY)
      .slice(0, topK);

    // Remove duplicate adjacent text
    const unique = deduplicateChunks(results);
    return unique;
  }

  function deduplicateChunks(chunks) {
    const seen = new Set();
    return chunks.filter(c => {
      const sig = c.text.slice(0, 100).toLowerCase().replace(/\s+/g, '');
      if (seen.has(sig)) return false;
      seen.add(sig);
      return true;
    });
  }

  // ---- Format sources for display ----
  function formatSources(chunks) {
    return chunks.map(c => ({
      documentId: c.documentId,
      documentName: c.documentName,
      pageNumber: c.pageNumber,
      chunkIndex: c.chunkIndex,
      excerpt: c.text.slice(0, 150) + (c.text.length > 150 ? '…' : ''),
      score: Math.round(c.score * 100),
    }));
  }

  // ---- Check if enough context exists ----
  function hasAdequateContext(chunks) {
    return chunks.length > 0 && chunks[0].score > MIN_SIMILARITY;
  }

  return { retrieve, formatSources, hasAdequateContext, computeSimilarity };
})();
