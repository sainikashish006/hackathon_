/**
 * StudyMate AI — Browser Voice Assistant
 * Uses the browser's Web Speech APIs; no audio is sent to StudyMate servers by this service.
 */
window.VoiceService = (() => {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let listening = false;

  function supported() {
    return !!Recognition;
  }

  function start({ onResult, onStart, onEnd, onError } = {}) {
    if (!supported()) throw new Error('Speech recognition is not supported in this browser. Try Chrome or Edge.');
    if (listening) return;

    recognition = new Recognition();
    recognition.lang = navigator.language || 'en-IN';
    recognition.interimResults = true;
    recognition.continuous = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => { listening = true; onStart?.(); };
    recognition.onresult = (event) => {
      let transcript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) transcript += event.results[i][0].transcript;
      onResult?.(transcript, event.results[event.results.length - 1].isFinal);
    };
    recognition.onerror = (event) => { listening = false; onError?.(event.error); };
    recognition.onend = () => { listening = false; onEnd?.(); };
    recognition.start();
  }

  function stop() {
    if (recognition) recognition.stop();
    listening = false;
  }

  function isListening() { return listening; }

  function speak(text, { lang = navigator.language || 'en-IN', rate = 1 } = {}) {
    if (!('speechSynthesis' in window)) throw new Error('Text-to-speech is not supported in this browser.');
    window.speechSynthesis.cancel();
    const clean = String(text).replace(/<[^>]*>/g, ' ').replace(/[#*_`]/g, '').replace(/\s+/g, ' ').trim();
    const utterance = new SpeechSynthesisUtterance(clean.slice(0, 5000));
    utterance.lang = lang;
    utterance.rate = rate;
    window.speechSynthesis.speak(utterance);
  }

  function stopSpeaking() { if ('speechSynthesis' in window) window.speechSynthesis.cancel(); }

  return { supported, start, stop, isListening, speak, stopSpeaking };
})();
