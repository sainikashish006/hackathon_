/**
 * StudyMate AI — URL Service
 * Extracts readable webpage text through Jina Reader.
 * For production, proxy this request through your own backend.
 */
window.URLService = (() => {
  function validate(url) {
    try {
      const parsed = new URL(url);
      if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Only HTTP/HTTPS URLs are supported.');
      return parsed.href;
    } catch (e) {
      throw new Error('Please enter a valid webpage URL, for example https://example.com');
    }
  }

  async function fetchPage(url) {
    const cleanUrl = validate(url.trim());
    const readerUrl = `https://r.jina.ai/${cleanUrl}`;
    const response = await fetch(readerUrl, {
      method: 'GET',
      headers: { 'Accept': 'text/plain' }
    });
    if (!response.ok) {
      throw new Error(`Could not read this webpage (${response.status}). Try another public URL.`);
    }
    const text = (await response.text()).trim();
    if (!text) throw new Error('The webpage did not return readable text.');
    return {
      url: cleanUrl,
      title: extractTitle(text, cleanUrl),
      text: text.slice(0, 30000),
    };
  }

  function extractTitle(text, fallback) {
    const first = text.split('\n').map(s => s.trim()).find(Boolean);
    return first ? first.slice(0, 180) : new URL(fallback).hostname;
  }

  return { fetchPage, validate };
})();
