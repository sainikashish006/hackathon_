/**
 * StudyMate AI — Application Configuration
 * Central config for plans, limits, and feature flags.
 * All limits are defined here — never hardcoded elsewhere.
 */

window.AppConfig = {
  APP_NAME: 'StudyMate AI',
  APP_VERSION: '1.0.0',
  TAGLINE: 'Your AI Study Partner for College',

  // AI provider — reads from a configured API key in localStorage
  AI: {
    PROVIDER: 'gemini', // 'gemini' | 'openai' | 'custom'
    MODEL: 'gemini-1.5-flash',
    MAX_TOKENS: 4096,
    TEMPERATURE: 0.7,
    // API keys must never be hardcoded here.
    // Key is read from a secure server-side proxy in production.
    // In this frontend-demo mode, user provides key in Settings.
    KEY_STORAGE: 'sm_ai_api_key', // localStorage key (dev only — never do this in production)
  },

  // Plan limits — single source of truth
  PLANS: {
    free: {
      name: 'Free',
      displayName: 'Free Plan',
      price: { monthly: 0, yearly: 0 },
      limits: {
        pdf_uploads_per_month:       5,
        ai_questions_per_month:     50,
        notes_generations_per_month: 5,
        quiz_generations_per_month:  5,
        pyq_analyses_per_month:      2,
        storage_mb:                100,
        max_file_size_mb:            5,
        flashcard_decks:            10,
        study_plans:                 1,
      },
      features: {
        rag_chat:          true,
        notes_generator:   true,
        quiz_generator:    true,
        flashcards:        true,
        pyq_analyzer:      true,
        study_planner:     true,
        exam_mode:         true,
        progress_tracking: true,
        export_notes:      false,
        advanced_analytics: false,
        priority_ai:       false,
        google_auth:       true,
      }
    },
    premium: {
      name: 'Premium',
      displayName: 'Premium Plan',
      price: { monthly: 299, yearly: 2499 },
      limits: {
        pdf_uploads_per_month:        50,
        ai_questions_per_month:      500,
        notes_generations_per_month:  50,
        quiz_generations_per_month:   50,
        pyq_analyses_per_month:       20,
        storage_mb:                 2048,
        max_file_size_mb:             20,
        flashcard_decks:           1000,
        study_plans:                 10,
      },
      features: {
        rag_chat:          true,
        notes_generator:   true,
        quiz_generator:    true,
        flashcards:        true,
        pyq_analyzer:      true,
        study_planner:     true,
        exam_mode:         true,
        progress_tracking: true,
        export_notes:      true,
        advanced_analytics: true,
        priority_ai:       true,
        google_auth:       true,
      }
    }
  },

  // File validation
  FILES: {
    ALLOWED_TYPES: ['application/pdf', 'text/plain', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
    ALLOWED_EXTENSIONS: ['.pdf', '.txt', '.docx'],
    MIME_TO_EXT: {
      'application/pdf': '.pdf',
      'text/plain': '.txt',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
    }
  },

  // RAG pipeline config
  RAG: {
    CHUNK_SIZE: 1000,       // characters per chunk
    CHUNK_OVERLAP: 200,     // overlap between chunks
    TOP_K: 5,              // number of chunks to retrieve
    MIN_SIMILARITY: 0.3,   // minimum similarity threshold
  },

  // UI feature flags
  FEATURES: {
    GOOGLE_AUTH: false,      // Set to true when OAuth is configured
    PAYMENT_LIVE: false,     // Set to true when payment provider is connected
    EMAIL_NOTIFICATIONS: false,
  },

  // Indian academic terms mapping
  ACADEMIC: {
    SEMESTERS: ['Semester 1','Semester 2','Semester 3','Semester 4','Semester 5','Semester 6','Semester 7','Semester 8'],
    COURSE_TYPES: ['B.Tech','BCA','BBA','MCA','MBA','B.Sc','M.Sc','B.Com','M.Com','BA','MA','Other'],
    EXAM_TYPES: ['Internal Exam (CT-1)','Internal Exam (CT-2)','Mid Semester Exam','End Semester Exam','Practical Exam','Viva','Assignment'],
    DEFAULT_SUBJECT_COLORS: ['#4F46E5','#06B6D4','#10B981','#F59E0B','#EF4444','#8B5CF6','#EC4899','#14B8A6'],
  },

  // Rate limiting (client-side — real rate limiting must be server-side)
  RATE_LIMIT: {
    AI_REQUEST_COOLDOWN_MS: 2000, // 2 seconds between AI requests
    UPLOAD_COOLDOWN_MS: 1000,
  },
};
