/**
 * StudyMate AI — App Shell: Topbar + Layout Wrapper
 */
window.AppShell = {
  renderLayout(title, content, opts = {}) {
    const { breadcrumb = '', actions = '' } = opts;
    SidebarComponent.init();
    const collapsed = SidebarComponent.sidebarCollapsed;

    return `
      <div class="app-layout">
        ${SidebarComponent.render()}
        <div id="mobile-backdrop" class="mobile-backdrop" onclick="SidebarComponent.closeMobile()"></div>

        <div class="main-content ${collapsed ? 'sidebar-collapsed' : ''}" id="main-content">
          <!-- Topbar -->
          <header class="topbar ${collapsed ? 'sidebar-collapsed' : ''}" id="app-topbar">
            <button class="hamburger-btn" onclick="SidebarComponent.openMobile()" aria-label="Open menu">
              <span></span><span></span><span></span>
            </button>

            <div class="topbar-breadcrumb">
              ${breadcrumb ? `<span>${breadcrumb}</span><span>›</span>` : ''}
              <span class="topbar-breadcrumb-current">${title}</span>
            </div>

            <div class="topbar-search">
              <span class="topbar-search-icon">🔍</span>
              <input type="text" placeholder="Search subjects, documents, notes…" 
                     id="global-search" autocomplete="off"
                     oninput="AppShell.handleSearch(this.value)" />
            </div>

            <div class="topbar-spacer"></div>

            <div class="topbar-actions">
              ${actions}
              <button class="btn btn-icon btn-ghost" onclick="AppShell.toggleTheme()" title="Toggle theme" aria-label="Toggle dark mode">◑</button>
              <button class="btn btn-sm btn-primary" onclick="Router.navigate('/ai-chat')">
                🤖 Ask AI
              </button>
            </div>
          </header>

          <!-- Page Content -->
          <main class="page-container animate-fade-in-up" id="page-content">
            ${content}
          </main>
        </div>
      </div>
    `;
  },

  handleSearch: Helpers.debounce((query) => {
    if (query.length < 2) return;
    // Global search — navigate to relevant section
    const q = query.toLowerCase();
    const subjects = DB.Subjects.list();
    const docs = DB.Documents.list();
    // Simple: show results in a mini dropdown
    // Full-page search would be implemented in a real app
  }, 400),

  toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    StorageService.set('theme', next);
  },

  initTheme() {
    const saved = StorageService.get('theme', 'light');
    document.documentElement.setAttribute('data-theme', saved);
  },
};
