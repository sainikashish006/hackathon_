/**
 * StudyMate AI — Sidebar Component
 */
window.SidebarComponent = {
  sidebarCollapsed: false,
  mobileSidebarOpen: false,

  getNavItems() {
    return [
      { section: 'Main' },
      { path: '/dashboard',    label: 'Dashboard',       icon: '⊞' },
      { path: '/subjects',     label: 'My Subjects',     icon: '📚' },
      { path: '/documents',    label: 'Documents',       icon: '📄' },
      { section: 'AI Tools' },
      { path: '/ai-chat',      label: 'AI Study Chat',   icon: '💬' },
      { path: '/notes',        label: 'Notes Generator', icon: '📝' },
      { path: '/quiz',         label: 'Quiz Generator',  icon: '✏️' },
      { path: '/flashcards',   label: 'Flashcards',      icon: '🃏' },
      { section: 'Exam Prep' },
      { path: '/pyq-analyzer', label: 'PYQ Analyzer',    icon: '🔍' },
      { path: '/study-planner',label: 'Study Planner',   icon: '📅' },
      { path: '/exam-mode',    label: 'Exam Mode',       icon: '⏱️' },
      { section: 'Account' },
      { path: '/progress',     label: 'Progress',        icon: '📊' },
      { path: '/profile',      label: 'Profile',         icon: '👤' },
      { path: '/pricing',      label: 'Subscription',    icon: '💎' },
      { path: '/help',         label: 'Help & FAQ',      icon: '❓' },
    ];
  },

  render() {
    const user = AuthService.getCurrentUser();
    const profile = AuthService.getProfile();
    const plan = DB.Subscriptions.getCurrentPlan();
    const currentPath = Router.getCurrentPath();
    const collapsed = this.sidebarCollapsed;

    const navItems = this.getNavItems().map(item => {
      if (item.section) {
        return `<div class="sidebar-section-label">${item.section}</div>`;
      }
      const isActive = currentPath === item.path;
      return `<a class="sidebar-item ${isActive ? 'active' : ''}" 
                 href="#${item.path}" 
                 data-tooltip="${item.label}"
                 onclick="SidebarComponent.closeMobile()">
        <span class="sidebar-item-icon">${item.icon}</span>
        <span class="sidebar-item-label">${item.label}</span>
      </a>`;
    }).join('');

    const initials = Helpers.getInitials(profile?.name || user?.name || 'U');
    const planBadge = plan === 'premium'
      ? '<span style="font-size:10px;background:linear-gradient(135deg,#F59E0B,#EF4444);color:white;padding:1px 6px;border-radius:9999px;font-weight:700;">PRO</span>'
      : '<span style="font-size:10px;background:var(--gray-200);color:var(--gray-600);padding:1px 6px;border-radius:9999px;font-weight:600;">FREE</span>';

    return `
      <aside class="sidebar ${collapsed ? 'collapsed' : ''}" id="app-sidebar">
        <a class="sidebar-logo" href="#/dashboard">
          <div class="sidebar-logo-icon">📚</div>
          <div class="sidebar-logo-text">Study<span>Mate</span> AI</div>
        </a>

        <nav class="sidebar-nav" id="sidebar-nav">
          ${navItems}
        </nav>

        <div class="sidebar-footer">
          <button class="sidebar-item" id="collapse-toggle" onclick="SidebarComponent.toggleCollapse()" data-tooltip="Collapse sidebar">
            <span class="sidebar-item-icon">${collapsed ? '→' : '←'}</span>
            <span class="sidebar-item-label">Collapse</span>
          </button>
          <div class="sidebar-user" onclick="Router.navigate('/profile')">
            <div class="avatar avatar-md avatar-initial">${initials}</div>
            <div class="sidebar-user-info">
              <div class="sidebar-user-name">${Helpers.truncate(profile?.name || user?.name || 'Student', 18)}</div>
              <div class="sidebar-user-plan">${planBadge}</div>
            </div>
          </div>
          <button class="sidebar-item" onclick="SidebarComponent.handleLogout()">
            <span class="sidebar-item-icon">🚪</span>
            <span class="sidebar-item-label">Logout</span>
          </button>
        </div>
      </aside>
    `;
  },

  toggleCollapse() {
    this.sidebarCollapsed = !this.sidebarCollapsed;
    const sidebar = document.getElementById('app-sidebar');
    const topbar  = document.getElementById('app-topbar');
    const content = document.getElementById('main-content');
    if (sidebar) sidebar.classList.toggle('collapsed', this.sidebarCollapsed);
    if (topbar)  topbar.classList.toggle('sidebar-collapsed', this.sidebarCollapsed);
    if (content) content.classList.toggle('sidebar-collapsed', this.sidebarCollapsed);
    StorageService.set('sidebar_collapsed', this.sidebarCollapsed);
  },

  openMobile() {
    this.mobileSidebarOpen = true;
    const sidebar  = document.getElementById('app-sidebar');
    const backdrop = document.getElementById('mobile-backdrop');
    if (sidebar)  sidebar.classList.add('mobile-open');
    if (backdrop) backdrop.classList.add('show');
  },

  closeMobile() {
    this.mobileSidebarOpen = false;
    const sidebar  = document.getElementById('app-sidebar');
    const backdrop = document.getElementById('mobile-backdrop');
    if (sidebar)  sidebar.classList.remove('mobile-open');
    if (backdrop) backdrop.classList.remove('show');
  },

  handleLogout() {
    Modal.confirm('Are you sure you want to log out?', () => {
      AuthService.logout();
      Router.navigate('/login');
      Toast.info('Logged out successfully');
    }, { title: 'Log Out', confirmText: 'Log Out', danger: true });
  },

  init() {
    this.sidebarCollapsed = StorageService.get('sidebar_collapsed', false);
  },
};
