/**
 * StudyMate AI — Upgrade Modal
 * Shown when user hits a usage limit.
 */
window.UpgradeModal = {
  show(metric, limitInfo) {
    const metricLabels = {
      pdf_uploads_per_month: 'PDF uploads',
      ai_questions_per_month: 'AI questions',
      notes_generations_per_month: 'notes generations',
      quiz_generations_per_month: 'quiz generations',
      pyq_analyses_per_month: 'PYQ analyses',
      storage_mb: 'storage',
    };
    const label = metricLabels[metric] || metric;
    const premiumPlan = AppConfig.PLANS.premium;
    const premiumLimit = premiumPlan.limits[metric] || '∞';

    Modal.show(`
      <div class="modal-header">
        <div style="display:flex;align-items:center;gap:12px;">
          <div style="width:40px;height:40px;border-radius:12px;background:linear-gradient(135deg,#F59E0B,#EF4444);display:flex;align-items:center;justify-content:center;font-size:20px;color:white;">💎</div>
          <div>
            <h3 class="modal-title">Upgrade to Premium</h3>
            <p style="font-size:12px;color:var(--text-muted);margin:0;">Unlock unlimited AI study tools</p>
          </div>
        </div>
        <button class="modal-close" onclick="Modal.close()">✕</button>
      </div>
      <div class="modal-body">
        <div class="alert alert-warning" style="margin-bottom:16px;">
          <span class="alert-icon">⚠</span>
          <span>You've used all <strong>${limitInfo?.limit} ${label}</strong> on your Free plan this month.</span>
        </div>

        <p style="font-size:14px;color:var(--text-secondary);margin-bottom:20px;">
          Upgrade to Premium to get <strong>${premiumLimit} ${label}</strong> per month and access all advanced study features.
        </p>

        <div style="background:var(--bg-raised);border-radius:12px;padding:16px;display:flex;flex-direction:column;gap:10px;margin-bottom:20px;">
          ${['500 AI questions/month','50 PDF uploads/month','Advanced PYQ analysis','Priority AI responses','Export notes','Advanced analytics'].map(f =>
            `<div style="display:flex;align-items:center;gap:8px;font-size:13px;">
              <span style="color:var(--brand-success);font-weight:700;">✓</span>
              <span>${f}</span>
            </div>`
          ).join('')}
        </div>

        <div style="text-align:center;">
          <div style="font-size:32px;font-weight:900;color:var(--text-primary);">₹299<span style="font-size:14px;font-weight:400;color:var(--text-muted)">/month</span></div>
          <div style="font-size:12px;color:var(--brand-success);margin-top:4px;">Save 30% with yearly billing → ₹2,499/year</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="Modal.close()">Continue Later</button>
        <button class="btn btn-primary" onclick="Modal.close();Router.navigate('/pricing')">
          💎 View Premium Plans
        </button>
      </div>
    `, { size: '' });
  },
};

/**
 * Usage Guard — check limit before AI operations
 */
window.UsageGuard = {
  async check(metric, onAllowed, onBlocked) {
    const result = UsageService.checkLimit(metric);
    if (!result.allowed) {
      UpgradeModal.show(metric, result);
      if (onBlocked) onBlocked(result);
      return false;
    }
    if (onAllowed) await onAllowed();
    return true;
  },
};
