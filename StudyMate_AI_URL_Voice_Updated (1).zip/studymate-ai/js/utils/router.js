/**
 * StudyMate AI — Router
 * Client-side SPA router using hash-based routing.
 * Route guards enforce authentication.
 */

window.Router = (() => {
  const routes = {};
  const guards = [];
  let currentRoute = null;
  let isNavigating = false;

  // Route definitions
  const PUBLIC_ROUTES = ['/', '/login', '/register', '/forgot-password', '/pricing', '/help'];
  const AUTH_ROUTES = ['/login', '/register'];

  function register(path, handler) {
    routes[path] = handler;
  }

  function addGuard(guardFn) {
    guards.push(guardFn);
  }

  function getCurrentPath() {
    const hash = window.location.hash;
    if (!hash || hash === '#') return '/';
    return hash.slice(1).split('?')[0] || '/';
  }

  function getQueryParams() {
    const hash = window.location.hash;
    if (!hash.includes('?')) return {};
    const query = hash.split('?')[1] || '';
    const params = {};
    query.split('&').forEach(pair => {
      const [key, val] = pair.split('=');
      if (key) params[decodeURIComponent(key)] = decodeURIComponent(val || '');
    });
    return params;
  }

  async function navigate(path, params = {}) {
    if (isNavigating) return;
    isNavigating = true;

    try {
      const queryStr = Object.keys(params).length
        ? '?' + Object.entries(params).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&')
        : '';

      window.location.hash = '#' + path + queryStr;
    } finally {
      isNavigating = false;
    }
  }

  async function resolve() {
    const path = getCurrentPath();
    const params = getQueryParams();

    // Run guards
    for (const guard of guards) {
      const result = guard(path, params);
      if (result && result !== path) {
        await navigate(result);
        return;
      }
    }

    // Find matching route
    let handler = routes[path];

    // Parameterized routes — try /path/:id patterns
    if (!handler) {
      for (const routePath of Object.keys(routes)) {
        if (routePath.includes(':')) {
          const pattern = new RegExp('^' + routePath.replace(/:[^/]+/g, '([^/]+)') + '$');
          const match = path.match(pattern);
          if (match) {
            handler = routes[routePath];
            // Extract path params
            const keys = routePath.match(/:[^/]+/g) || [];
            keys.forEach((k, i) => { params[k.slice(1)] = match[i + 1]; });
            break;
          }
        }
      }
    }

    if (!handler) {
      handler = routes['/404'] || (() => render404());
    }

    currentRoute = { path, params };
    const root = document.getElementById('app-root');
    if (root) {
      root.className = 'page-enter';
      root.innerHTML = '';
    }

    try {
      await handler(params, path);
    } catch (err) {
      console.error('Route error:', err);
      renderError(err.message);
    }
  }

  function render404() {
    const root = document.getElementById('app-root');
    if (!root) return;
    root.innerHTML = `
      <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px;text-align:center;padding:24px;">
        <div style="font-size:80px;">🔍</div>
        <h1 style="font-size:32px;font-weight:800;">Page Not Found</h1>
        <p style="color:#64748B;">This page doesn't exist or has been moved.</p>
        <a href="#/" class="btn btn-primary">Go Home</a>
      </div>`;
  }

  function renderError(msg) {
    const root = document.getElementById('app-root');
    if (!root) return;
    root.innerHTML = `
      <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px;text-align:center;padding:24px;">
        <div style="font-size:64px;">⚠️</div>
        <h1 style="font-size:24px;font-weight:700;">Something went wrong</h1>
        <p style="color:#64748B;max-width:400px;">An unexpected error occurred. Please refresh the page.</p>
        <button class="btn btn-primary" onclick="window.location.reload()">Refresh</button>
      </div>`;
  }

  function init() {
    // Authentication guard
    addGuard((path) => {
      const isAuthed = AuthService.isAuthenticated();
      const isPublic = PUBLIC_ROUTES.some(r => path === r || path.startsWith(r + '/'));
      const isAuthRoute = AUTH_ROUTES.includes(path);

      if (!isAuthed && !isPublic) return '/login';
      if (isAuthed && isAuthRoute) return '/dashboard';
      return null;
    });

    window.addEventListener('hashchange', () => resolve());
    resolve();
  }

  return { register, navigate, resolve, getCurrentPath, getQueryParams, init, currentRoute: () => currentRoute };
})();
