/**
 * StudyMate AI — Toast Notifications
 */

window.Toast = (() => {
  const DURATION = 4000;

  function getContainer() {
    let container = document.getElementById('toast-root');
    if (!container) return null;
    if (!container.querySelector('.toast-container')) {
      const el = document.createElement('div');
      el.className = 'toast-container';
      container.appendChild(el);
    }
    return container.querySelector('.toast-container');
  }

  function show(message, type = 'default', duration = DURATION) {
    const container = getContainer();
    if (!container) return;

    const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ', default: '•' };
    const toast = document.createElement('div');
    toast.className = `toast ${type !== 'default' ? type : ''}`;
    toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.default}</span><span class="toast-text">${message}</span>`;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.transition = 'all 0.3s ease';
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => toast.remove(), 300);
    }, duration);

    return toast;
  }

  return {
    success: (msg, dur) => show(msg, 'success', dur),
    error:   (msg, dur) => show(msg, 'error', dur),
    warning: (msg, dur) => show(msg, 'warning', dur),
    info:    (msg, dur) => show(msg, 'info', dur),
    show,
  };
})();
