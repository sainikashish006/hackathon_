/**
 * StudyMate AI — Shared Helpers & Icons
 */

// ---- Icons ----
window.Icons = {
  dashboard: '⊞',
  subjects:  '📚',
  documents: '📄',
  chat:      '💬',
  notes:     '📝',
  quiz:      '✏️',
  pyq:       '🔍',
  planner:   '📅',
  flashcards:'🃏',
  exam:      '⏱️',
  progress:  '📊',
  profile:   '👤',
  pricing:   '💎',
  help:      '❓',
  settings:  '⚙️',
  logout:    '🚪',
  upload:    '⬆️',
  ai:        '🤖',
  success:   '✓',
  error:     '✕',
  warning:   '⚠',
  info:      'ℹ',
  close:     '✕',
  add:       '+',
  edit:      '✏',
  delete:    '🗑',
  copy:      '⧉',
  save:      '💾',
  download:  '⬇',
  share:     '↗',
  refresh:   '↻',
  search:    '🔍',
  filter:    '⊟',
  star:      '★',
  clock:     '⏱',
  calendar:  '📅',
  book:      '📖',
  brain:     '🧠',
  fire:      '🔥',
  trophy:    '🏆',
  rocket:    '🚀',
  lightbulb: '💡',
  check:     '✓',
  arrow_right:'→',
  arrow_left: '←',
  chevron_down:'▾',
  chevron_up: '▴',
  external:  '↗',
  lock:      '🔒',
  unlock:    '🔓',
  pdf:       '📑',
  doc:       '📃',
  txt:       '📄',
  link:      '🔗',
  percent:   '%',
  user:      '👤',
  users:     '👥',
  bell:      '🔔',
  menu:      '☰',
  more:      '⋯',
  sort:      '⇅',
  collapse:  '⊟',
  expand:    '⊞',
  theme:     '◑',
  sparkle:   '✨',
  zap:       '⚡',
};

// ---- Helpers ----
window.Helpers = {
  // Format date
  formatDate(dateStr, options = {}) {
    if (!dateStr) return '—';
    const date = new Date(dateStr);
    if (isNaN(date)) return dateStr;
    const defaults = { day: 'numeric', month: 'short', year: 'numeric' };
    return date.toLocaleDateString('en-IN', { ...defaults, ...options });
  },

  // Format relative time
  timeAgo(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return this.formatDate(dateStr);
  },

  // Format file size
  fileSize(bytes) {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
  },

  // Escape HTML
  escapeHtml(str) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(str || ''));
    return div.innerHTML;
  },

  // Debounce
  debounce(fn, delay = 300) {
    let timer;
    return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
  },

  // Truncate text
  truncate(text, length = 80) {
    if (!text) return '';
    return text.length > length ? text.slice(0, length) + '…' : text;
  },

  // Generate avatar initials
  getInitials(name) {
    if (!name) return '?';
    return name.trim().split(/\s+/).map(n => n[0]).join('').toUpperCase().slice(0, 2);
  },

  // Format score
  formatScore(score) {
    return Math.round(score) + '%';
  },

  // Score color
  scoreColor(score) {
    if (score >= 80) return 'var(--brand-success)';
    if (score >= 60) return 'var(--brand-accent)';
    return 'var(--brand-danger)';
  },

  // Pluralize
  plural(count, singular, plural = singular + 's') {
    return count === 1 ? `${count} ${singular}` : `${count} ${plural}`;
  },

  // Copy to clipboard
  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      Toast.success('Copied to clipboard');
      return true;
    } catch {
      const el = document.createElement('textarea');
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      Toast.success('Copied to clipboard');
      return true;
    }
  },

  // Get subject color dot
  colorDot(color, size = 10) {
    return `<span class="subject-color-dot" style="background:${color};width:${size}px;height:${size}px;"></span>`;
  },

  // Render skeleton
  skeleton(width = '100%', height = '16px') {
    return `<div class="skeleton" style="width:${width};height:${height};border-radius:4px;"></div>`;
  },

  // Format duration (minutes)
  formatDuration(minutes) {
    if (!minutes) return '0 min';
    if (minutes < 60) return `${minutes} min`;
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return m > 0 ? `${h}h ${m}m` : `${h}h`;
  },

  // Generate short unique ID for DOM elements
  uid(prefix = 'el') {
    return prefix + '_' + Math.random().toString(36).slice(2, 7);
  },

  // HTML to text (strip tags)
  stripHtml(html) {
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || '';
  },

  // Render markdown-like text (basic)
  renderMarkdown(text) {
    if (!text) return '';
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`(.*?)`/g, '<code>$1</code>')
      .replace(/^#{3} (.+)$/gm, '<h3>$1</h3>')
      .replace(/^#{2} (.+)$/gm, '<h2>$1</h2>')
      .replace(/^#{1} (.+)$/gm, '<h1>$1</h1>')
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/\n/g, '<br>');
  },
};
