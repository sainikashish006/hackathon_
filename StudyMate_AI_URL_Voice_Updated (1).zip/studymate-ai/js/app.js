/**
 * StudyMate AI — Main App Entry Point
 * Bootstraps services, registers routes, and initializes the SPA.
 */

(function init() {
  // ---- Load persisted AI config ----
  AppConfig.AI.PROVIDER = localStorage.getItem('ai_provider') || AppConfig.AI.PROVIDER;
  AppConfig.AI.MODEL    = localStorage.getItem('ai_model')    || AppConfig.AI.MODEL;

  // ---- Theme ----
  AppShell.initTheme();

  // ---- Register Routes ----
  Router.register('/',                () => { if (AuthService.isAuthenticated()) { Router.navigate('/dashboard'); } else { LandingPage.render(); } });
  Router.register('/login',           () => LoginPage.render());
  Router.register('/register',        () => RegisterPage.render());
  Router.register('/forgot-password', () => ForgotPasswordPage.render());
  Router.register('/dashboard',       () => DashboardPage.render());
  Router.register('/subjects',        (p) => SubjectsPage.render(p));
  Router.register('/documents',       (p) => DocumentsPage.render(p));
  Router.register('/ai-chat',         (p) => AIChatPage.render(p));
  Router.register('/notes',           (p) => NotesPage.render(p));
  Router.register('/quiz',            (p) => QuizPage.render(p));
  Router.register('/flashcards',      (p) => FlashcardsPage.render(p));
  Router.register('/pyq-analyzer',    (p) => PYQAnalyzerPage.render(p));
  Router.register('/study-planner',   (p) => StudyPlannerPage.render(p));
  Router.register('/exam-mode',       (p) => ExamModePage.render(p));
  Router.register('/progress',        (p) => ProgressPage.render(p));
  Router.register('/profile',         (p) => ProfilePage.render(p));
  Router.register('/pricing',         (p) => PricingPage.render(p));
  Router.register('/help',            (p) => HelpPage.render());
  Router.register('/404',             () => {
    document.getElementById('app-root').innerHTML = `
      <div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;text-align:center;padding:24px;">
        <div style="font-size:80px;">🔍</div>
        <h1 style="font-size:36px;font-weight:900;">404 — Page Not Found</h1>
        <p style="color:var(--text-muted);">This page doesn't exist.</p>
        <a href="#/" class="btn btn-primary">Go Home</a>
      </div>
    `;
  });

  // ---- Init Router ----
  Router.init();

  console.log('StudyMate AI initialized ✓');
})();
